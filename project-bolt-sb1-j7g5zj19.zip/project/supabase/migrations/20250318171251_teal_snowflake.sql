/*
  # Update project RLS policies

  1. Changes
    - Add comprehensive RLS policies for projects table
    - Enable policies for SELECT, INSERT, UPDATE, and DELETE operations

  2. Security
    - Ensures users can read their own projects
    - Maintains data integrity with proper user_id checks
    - Prevents unauthorized access to other users' projects
*/

-- Drop existing policies to avoid conflicts
DROP POLICY IF EXISTS "Users can create their own projects" ON projects;
DROP POLICY IF EXISTS "Users can manage their own projects" ON projects;

-- Add new comprehensive policies
CREATE POLICY "Users can read their own projects"
  ON projects
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own projects"
  ON projects
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own projects"
  ON projects
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own projects"
  ON projects
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);