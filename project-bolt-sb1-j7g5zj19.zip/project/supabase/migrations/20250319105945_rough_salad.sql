/*
  # Fix Photos RLS Policies

  1. Changes
    - Enable RLS on photos table
    - Add policies for authenticated users to:
      - Insert photos
      - Read their own photos
      - Update their own photos
      - Delete their own photos

  2. Security
    - Users can only access photos in their own projects
    - Project ownership is verified through the projects table
*/

-- Enable RLS on photos table
ALTER TABLE photos ENABLE ROW LEVEL SECURITY;

-- Allow users to insert photos for their own projects
CREATE POLICY "Users can insert photos for their own projects"
ON photos
FOR INSERT
TO authenticated
WITH CHECK (
  project_id IN (
    SELECT id FROM projects
    WHERE user_id = auth.uid()
  )
);

-- Allow users to read photos from their own projects
CREATE POLICY "Users can read photos from their own projects"
ON photos
FOR SELECT
TO authenticated
USING (
  project_id IN (
    SELECT id FROM projects
    WHERE user_id = auth.uid()
  )
);

-- Allow users to update photos in their own projects
CREATE POLICY "Users can update photos in their own projects"
ON photos
FOR UPDATE
TO authenticated
USING (
  project_id IN (
    SELECT id FROM projects
    WHERE user_id = auth.uid()
  )
)
WITH CHECK (
  project_id IN (
    SELECT id FROM projects
    WHERE user_id = auth.uid()
  )
);

-- Allow users to delete photos from their own projects
CREATE POLICY "Users can delete photos from their own projects"
ON photos
FOR DELETE
TO authenticated
USING (
  project_id IN (
    SELECT id FROM projects
    WHERE user_id = auth.uid()
  )
);

-- Create storage policy for photos bucket
BEGIN;
  -- Create photos bucket if it doesn't exist
  INSERT INTO storage.buckets (id, name)
  VALUES ('photos', 'photos')
  ON CONFLICT (id) DO NOTHING;

  -- Enable RLS on storage bucket
  ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

  -- Create policy to allow authenticated users to upload files
  CREATE POLICY "Authenticated users can upload files"
  ON storage.objects
  FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'photos' AND
    auth.uid()::text = (storage.foldername(name))[1]
  );

  -- Create policy to allow authenticated users to read their own files
  CREATE POLICY "Users can read their own files"
  ON storage.objects
  FOR SELECT
  TO authenticated
  USING (
    bucket_id = 'photos' AND
    auth.uid()::text = (storage.foldername(name))[1]
  );

  -- Create policy to allow authenticated users to update their own files
  CREATE POLICY "Users can update their own files"
  ON storage.objects
  FOR UPDATE
  TO authenticated
  USING (
    bucket_id = 'photos' AND
    auth.uid()::text = (storage.foldername(name))[1]
  )
  WITH CHECK (
    bucket_id = 'photos' AND
    auth.uid()::text = (storage.foldername(name))[1]
  );

  -- Create policy to allow authenticated users to delete their own files
  CREATE POLICY "Users can delete their own files"
  ON storage.objects
  FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'photos' AND
    auth.uid()::text = (storage.foldername(name))[1]
  );
COMMIT;