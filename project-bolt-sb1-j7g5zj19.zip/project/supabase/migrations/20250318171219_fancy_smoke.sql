/*
  # Add project creation policy

  1. Changes
    - Add RLS policy to allow authenticated users to create new projects
    - Policy ensures user_id is set to the authenticated user's ID

  2. Security
    - Ensures users can only create projects with their own user_id
    - Maintains data integrity by preventing unauthorized project creation
*/

CREATE POLICY "Users can create their own projects"
  ON projects
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);