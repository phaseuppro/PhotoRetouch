/*
  # Create storage bucket for photos

  1. New Storage
    - Create a new storage bucket named 'photos' for storing project images
  2. Security
    - Enable RLS on the bucket
    - Add policy for authenticated users to manage their own photos
*/

-- Create the photos bucket if it doesn't exist
INSERT INTO storage.buckets (id, name, public)
VALUES ('photos', 'photos', false)
ON CONFLICT (id) DO NOTHING;

-- Enable RLS
ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

-- Create policy to allow authenticated users to manage their photos
CREATE POLICY "Users can manage their photos"
ON storage.objects
FOR ALL
TO authenticated
USING (bucket_id = 'photos' AND auth.uid()::text = (storage.foldername(name))[1])
WITH CHECK (bucket_id = 'photos' AND auth.uid()::text = (storage.foldername(name))[1]);