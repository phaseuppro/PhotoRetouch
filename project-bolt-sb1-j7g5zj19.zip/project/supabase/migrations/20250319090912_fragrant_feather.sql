/*
  # Fix tokens table RLS policies

  1. Changes
    - Add INSERT policy for tokens table
    - Ensure users can create their initial token record
    - Maintain existing SELECT and UPDATE policies

  2. Security
    - Users can only create tokens for themselves
    - Maintains data integrity with proper user_id checks
*/

-- Add INSERT policy for tokens
CREATE POLICY "Users can create their own tokens"
  ON tokens
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Ensure existing policies are correct
DROP POLICY IF EXISTS "Users can read their own tokens" ON tokens;
DROP POLICY IF EXISTS "Users can update their own tokens" ON tokens;

CREATE POLICY "Users can read their own tokens"
  ON tokens
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own tokens"
  ON tokens
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);