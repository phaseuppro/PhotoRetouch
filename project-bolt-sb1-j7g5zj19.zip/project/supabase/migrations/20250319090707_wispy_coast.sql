/*
  # Add subscription and token system

  1. New Tables
    - `subscriptions`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `status` (text) - active, canceled, past_due
      - `current_period_start` (timestamptz)
      - `current_period_end` (timestamptz)
      - `created_at` (timestamptz)
    - `tokens`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `amount` (int) - current token balance
      - `updated_at` (timestamptz)

  2. Changes to existing tables
    - Add `tokens_used` column to photos table

  3. Security
    - Enable RLS on new tables
    - Add policies for users to read their own subscription and token data
*/

-- Create subscriptions table
CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id),
  status text NOT NULL DEFAULT 'active',
  current_period_start timestamptz NOT NULL DEFAULT now(),
  current_period_end timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  CONSTRAINT valid_status CHECK (status IN ('active', 'canceled', 'past_due'))
);

-- Create tokens table
CREATE TABLE IF NOT EXISTS tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) UNIQUE,
  amount integer NOT NULL DEFAULT 0,
  updated_at timestamptz DEFAULT now()
);

-- Add tokens_used column to photos
ALTER TABLE photos ADD COLUMN IF NOT EXISTS tokens_used integer DEFAULT 0;

-- Enable RLS
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE tokens ENABLE ROW LEVEL SECURITY;

-- Create policies for subscriptions
CREATE POLICY "Users can read their own subscription"
  ON subscriptions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Create policies for tokens
CREATE POLICY "Users can read their own tokens"
  ON tokens
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update their own tokens"
  ON tokens
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Function to add monthly tokens
CREATE OR REPLACE FUNCTION add_monthly_tokens()
RETURNS trigger AS $$
BEGIN
  INSERT INTO tokens (user_id, amount)
  VALUES (NEW.user_id, 20)
  ON CONFLICT (user_id)
  DO UPDATE SET amount = tokens.amount + 20,
                updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to add tokens when subscription renews
CREATE TRIGGER add_monthly_tokens_trigger
  AFTER INSERT OR UPDATE OF current_period_start
  ON subscriptions
  FOR EACH ROW
  EXECUTE FUNCTION add_monthly_tokens();