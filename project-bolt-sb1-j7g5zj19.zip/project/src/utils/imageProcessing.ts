import * as tf from '@tensorflow/tfjs';
import { SubjectType } from '../components/SubjectSelector';

// Initialize TensorFlow.js with WebGL backend
async function initTF() {
  await tf.setBackend('webgl');
  await tf.ready();
  console.log('TensorFlow.js initialized with backend:', tf.getBackend());
}

// Initialize TensorFlow.js when the module loads
initTF().catch(console.error);

export interface ProcessingSettings {
  strength?: number;
  radius?: number;
  detail?: number;
  brightness?: number;
  warmth?: number;
  smoothness?: number;
  exposure?: number;
  contrast?: number;
  highlights?: number;
  clarity?: number;
  texture?: number;
  sharpness?: number;
  // Subject-specific settings
  naturalness?: number;
  preservation?: number;
  character?: number;
  delicacy?: number;
  structure?: number;
  softness?: number;
  glow?: number;
}

interface PersonDetection {
  box: [number, number, number, number]; // [x, y, width, height]
  class: SubjectType;
  confidence: number;
}

function createCanvas(width: number, height: number): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  return canvas;
}

// Detect people in the image and their types
async function detectPeople(imageData: ImageData): Promise<PersonDetection[]> {
  // This is a placeholder for actual ML-based person detection
  // In a real implementation, this would use TensorFlow.js to detect people
  // and classify them by type (male, female, child, etc.)
  return [
    {
      box: [100, 100, 200, 400],
      class: 'female',
      confidence: 0.95
    },
    {
      box: [400, 100, 200, 400],
      class: 'male',
      confidence: 0.92
    }
  ];
}

// Create a mask for the selected person
function createPersonMask(
  width: number, 
  height: number, 
  detection: PersonDetection
): ImageData {
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d')!;
  
  // Create mask
  ctx.fillStyle = 'black';
  ctx.fillRect(0, 0, width, height);
  ctx.fillStyle = 'white';
  ctx.fillRect(
    detection.box[0],
    detection.box[1],
    detection.box[2],
    detection.box[3]
  );
  
  return ctx.getImageData(0, 0, width, height);
}

export async function processImage(
  imageUrl: string,
  tool: string,
  settings: ProcessingSettings,
  subject?: SubjectType
): Promise<string> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onerror = () => reject(new Error('Failed to load image'));
    
    img.onload = async () => {
      try {
        // Create canvas and draw image
        const canvas = createCanvas(img.width, img.height);
        const ctx = canvas.getContext('2d')!;
        ctx.drawImage(img, 0, 0);
        
        // Get image data
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        
        // Detect people in the image
        const detections = await detectPeople(imageData);
        
        // Find the selected person
        const selectedPerson = detections.find(d => d.class === subject);
        
        if (selectedPerson) {
          // Create mask for selected person
          const mask = createPersonMask(canvas.width, canvas.height, selectedPerson);
          
          // Apply processing only to masked area
          const processedData = new Uint8ClampedArray(imageData.data);
          for (let i = 0; i < imageData.data.length; i += 4) {
            const maskAlpha = mask.data[i + 3];
            if (maskAlpha > 0) {
              // Apply subject-specific adjustments
              if (subject) {
                applySubjectPresets(processedData, i, subject);
              }
              
              // Process image based on tool
              switch (tool) {
                case 'auto':
                  autoEnhance(processedData, i, subject);
                  break;
                case 'skin':
                  smoothSkin(processedData, i, settings.smoothness || 0, subject);
                  break;
                case 'tone':
                  adjustTone(processedData, i, settings, subject);
                  break;
                case 'light':
                  adjustLight(processedData, i, settings);
                  break;
              }
            }
          }
          
          // Put processed data back to canvas
          const processedImageData = new ImageData(
            processedData,
            canvas.width,
            canvas.height
          );
          ctx.putImageData(processedImageData, 0, 0);
        }
        
        // Return as data URL
        resolve(canvas.toDataURL('image/jpeg', 0.92));
      } catch (error) {
        console.error('Processing error:', error);
        reject(error);
      }
    };
    
    img.src = imageUrl;
  });
}

function applySubjectPresets(data: Uint8ClampedArray, i: number, subject: SubjectType): void {
  switch (subject) {
    case 'newborn':
      // Extra gentle processing for newborns
      applySoftGlow(data, i, 0.3);
      break;
    case 'child':
      // Preserve natural skin texture for children
      preserveTexture(data, i, 0.8);
      break;
    case 'senior':
      // Maintain character while reducing harsh lines
      balanceDetail(data, i, 0.6);
      break;
    case 'male':
      // Enhance structure while maintaining natural look
      enhanceStructure(data, i, 0.5);
      break;
    case 'female':
      // Subtle enhancement with soft glow
      applySoftGlow(data, i, 0.5);
      break;
  }
}

function applySoftGlow(data: Uint8ClampedArray, i: number, intensity: number): void {
  const factor = 1 + intensity * 0.2;
  data[i] = Math.min(255, data[i] * factor);
  data[i + 1] = Math.min(255, data[i + 1] * factor);
  data[i + 2] = Math.min(255, data[i + 2] * factor);
}

function preserveTexture(data: Uint8ClampedArray, i: number, strength: number): void {
  const factor = strength * 0.5;
  for (let j = 0; j < 3; j++) {
    const value = data[i + j];
    data[i + j] = Math.round(value * (1 - factor) + value * factor);
  }
}

function balanceDetail(data: Uint8ClampedArray, i: number, strength: number): void {
  const factor = strength * 0.3;
  for (let j = 0; j < 3; j++) {
    const value = data[i + j];
    data[i + j] = Math.round(value * (1 - factor) + (value * 0.8) * factor);
  }
}

function enhanceStructure(data: Uint8ClampedArray, i: number, strength: number): void {
  const factor = strength * 0.4;
  for (let j = 0; j < 3; j++) {
    const value = data[i + j];
    data[i + j] = Math.round(value * (1 - factor) + (value * 1.2) * factor);
  }
}

function autoEnhance(data: Uint8ClampedArray, i: number, subject?: SubjectType): void {
  let contrast = 1.1;
  let brightness = 5;

  // Adjust parameters based on subject
  if (subject) {
    switch (subject) {
      case 'newborn':
        contrast = 1.05;
        brightness = 3;
        break;
      case 'child':
        contrast = 1.08;
        brightness = 4;
        break;
      case 'senior':
        contrast = 1.12;
        brightness = 6;
        break;
      case 'male':
        contrast = 1.15;
        brightness = 5;
        break;
      case 'female':
        contrast = 1.1;
        brightness = 4;
        break;
    }
  }
  
  for (let j = 0; j < 3; j++) {
    const value = data[i + j];
    data[i + j] = Math.max(0, Math.min(255,
      Math.round(((value / 255 - 0.5) * contrast + 0.5) * 255 + brightness)
    ));
  }
}

function smoothSkin(data: Uint8ClampedArray, i: number, strength: number, subject?: SubjectType): void {
  if (strength === 0) return;
  
  // Adjust strength based on subject
  let adjustedStrength = strength;
  if (subject) {
    switch (subject) {
      case 'newborn':
        adjustedStrength *= 0.5; // Very gentle smoothing
        break;
      case 'child':
        adjustedStrength *= 0.7; // Light smoothing
        break;
      case 'senior':
        adjustedStrength *= 0.9; // Moderate smoothing
        break;
      case 'male':
        adjustedStrength *= 0.8; // Preserve more texture
        break;
      case 'female':
        adjustedStrength *= 1.0; // Standard smoothing
        break;
    }
  }
  
  const factor = adjustedStrength / 100;
  for (let j = 0; j < 3; j++) {
    data[i + j] = Math.round(data[i + j] * (1 - factor) + data[i + j] * factor);
  }
}

function adjustTone(data: Uint8ClampedArray, i: number, settings: ProcessingSettings, subject?: SubjectType): void {
  let brightness = ((settings.brightness || 50) - 50) / 50;
  let warmth = ((settings.warmth || 50) - 50) / 50;
  
  // Adjust parameters based on subject
  if (subject) {
    switch (subject) {
      case 'newborn':
        warmth *= 0.7; // Softer, more neutral tones
        brightness *= 0.8;
        break;
      case 'child':
        warmth *= 0.9; // Natural, slightly warm tones
        brightness *= 0.9;
        break;
      case 'senior':
        warmth *= 1.1; // Slightly warmer tones
        brightness *= 1.1;
        break;
      case 'male':
        warmth *= 0.9; // More neutral tones
        brightness *= 1.0;
        break;
      case 'female':
        warmth *= 1.1; // Slightly warmer tones
        brightness *= 1.0;
        break;
    }
  }
  
  // Adjust brightness
  for (let j = 0; j < 3; j++) {
    data[i + j] = Math.max(0, Math.min(255,
      Math.round(data[i + j] + brightness * 50)
    ));
  }
  
  // Adjust warmth (red-blue balance)
  data[i] = Math.max(0, Math.min(255, Math.round(data[i] + warmth * 30))); // Red
  data[i + 2] = Math.max(0, Math.min(255, Math.round(data[i + 2] - warmth * 30))); // Blue
}

function adjustLight(data: Uint8ClampedArray, i: number, settings: ProcessingSettings): void {
  const exposure = Math.exp(((settings.exposure || 50) - 50) / 50);
  const contrast = (settings.contrast || 50) / 50;
  
  for (let j = 0; j < 3; j++) {
    // Apply exposure
    let value = data[i + j] * exposure;
    
    // Apply contrast
    value = ((value / 255 - 0.5) * contrast + 0.5) * 255;
    
    data[i + j] = Math.max(0, Math.min(255, Math.round(value)));
  }
}