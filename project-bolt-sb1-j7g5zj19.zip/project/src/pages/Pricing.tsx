import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Sparkles, Check, CreditCard, Mail } from 'lucide-react';
import { loadStripe } from '@stripe/stripe-js';
import { supabase } from '../lib/supabase';

const stripePromise = loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY);

const plans = [
  {
    name: 'Pay as you go',
    price: '0.14',
    currency: '€',
    interval: 'credit',
    options: [
      { credits: 200, price: 49 },
      { credits: 500, price: 89 },
      { credits: 1200, price: 169 },
      { credits: 3600, price: 459 }
    ],
    features: [
      '1,200 credits included',
      'Support for 2 devices',
      'Credits valid for 2 years'
    ],
    priceId: 'price_payg'
  },
  {
    name: 'Annual Subscription',
    price: '0.06',
    currency: '€',
    interval: 'credit',
    popular: true,
    savePercent: 10,
    options: [
      { name: 'Starter Plan', credits: 800, price: 75, oldPrice: 83 },
      { name: 'Basic Plan', credits: 1600, price: 125, oldPrice: 139 },
      { name: 'Basic Plus Plan', credits: 3600, price: 224, oldPrice: 249 },
      { name: 'Standard Plan', credits: 9000, price: 485, oldPrice: 539 },
      { name: 'Standard Plus Plan', credits: 24000, price: 1106, oldPrice: 1229 }
    ],
    features: [
      '3,600 credits included',
      'Support for 3 devices',
      'Unused credits roll over',
      'Annual billing'
    ],
    priceId: 'price_annual'
  },
  {
    name: 'Enterprise Plan',
    price: null,
    subtitle: 'Best choice for editors with high volume',
    features: [
      'Competitive pricing',
      'Flexible team credit management',
      'Priority support',
      'Dedicated customer success manager'
    ],
    isEnterprise: true
  }
];

export function PricingPage() {
  const navigate = useNavigate();

  const handleSubscribe = async (priceId: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate('/login?redirect=/pricing');
        return;
      }

      const { data: session, error: sessionError } = await supabase.functions.invoke('create-checkout-session', {
        body: { priceId, userId: user.id }
      });

      if (sessionError) throw sessionError;

      const stripe = await stripePromise;
      if (!stripe) throw new Error('Stripe failed to load');

      const { error } = await stripe.redirectToCheckout({
        sessionId: session.id
      });

      if (error) throw error;
    } catch (err) {
      console.error('Subscription error:', err);
    }
  };

  const handleContactSales = () => {
    window.location.href = 'mailto:sales@example.com';
  };

  return (
    <div className="min-h-screen bg-[var(--app-bg)] py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center mb-4">
            <Sparkles className="w-8 h-8 text-[var(--accent-color)]" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-4">
            Choose Your Plan
          </h1>
          <p className="text-lg text-[var(--text-secondary)] max-w-2xl mx-auto">
            Select the perfect plan for your needs
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`relative bg-[var(--panel-bg)] rounded-2xl p-8 border ${
                plan.popular
                  ? 'border-[var(--accent-color)]'
                  : 'border-[var(--border-color)]'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-[var(--accent-color)] text-white text-sm font-medium px-3 py-1 rounded-full">
                    Save {plan.savePercent}%
                  </div>
                </div>
              )}

              <div className="text-center mb-8">
                <h3 className="text-xl font-semibold text-white mb-2">
                  {plan.name}
                </h3>
                {plan.subtitle && (
                  <p className="text-sm text-[var(--text-secondary)] mb-4">
                    {plan.subtitle}
                  </p>
                )}
                {plan.price && (
                  <div className="flex items-center justify-center mb-2">
                    <span className="text-sm text-[var(--text-secondary)]">
                      {plan.currency}
                    </span>
                    <span className="text-4xl font-bold text-white mx-1">
                      {plan.price}
                    </span>
                    <span className="text-[var(--text-secondary)]">
                      /{plan.interval}
                    </span>
                  </div>
                )}
              </div>

              {plan.options && (
                <div className="mb-8 space-y-3">
                  {plan.options.map((option) => (
                    <div
                      key={option.credits}
                      className="flex items-center justify-between p-3 rounded bg-[var(--hover-bg)]"
                    >
                      <div>
                        {option.name && (
                          <div className="font-medium text-white">
                            {option.name}
                          </div>
                        )}
                        <div className="text-[var(--text-secondary)]">
                          {option.credits.toLocaleString()} credits
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-white font-medium">
                          {option.price}€
                        </div>
                        {option.oldPrice && (
                          <div className="text-sm text-red-500 line-through">
                            {option.oldPrice}€
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <div className="space-y-4 mb-8">
                {plan.features.map((feature) => (
                  <div key={feature} className="flex items-start">
                    <Check className="w-5 h-5 text-[var(--accent-color)] mr-3 flex-shrink-0 mt-0.5" />
                    <span className="text-[var(--text-secondary)]">{feature}</span>
                  </div>
                ))}
              </div>

              {plan.isEnterprise ? (
                <button
                  onClick={handleContactSales}
                  className="w-full flex items-center justify-center px-6 py-3 rounded-lg text-white bg-[var(--hover-bg)] hover:bg-opacity-80 transition-colors"
                >
                  <Mail className="w-4 h-4 mr-2" />
                  Contact Sales
                </button>
              ) : (
                <button
                  onClick={() => handleSubscribe(plan.priceId)}
                  className={`w-full flex items-center justify-center px-6 py-3 rounded-lg text-white transition-colors ${
                    plan.popular
                      ? 'bg-[var(--accent-color)] hover:opacity-90'
                      : 'bg-[var(--hover-bg)] hover:bg-opacity-80'
                  }`}
                >
                  <CreditCard className="w-4 h-4 mr-2" />
                  Purchase Now
                </button>
              )}

              {plan.price && (
                <p className="mt-4 text-xs text-center text-[var(--text-secondary)]">
                  Price includes tax. Price per credit is approximate and may vary slightly.
                </p>
              )}
            </div>
          ))}
        </div>

        {/* FAQ */}
        <div className="mt-20 max-w-3xl mx-auto">
          <h2 className="text-2xl font-semibold text-white text-center mb-8">
            Frequently Asked Questions
          </h2>
          <div className="space-y-6">
            <div>
              <h3 className="text-lg font-medium text-white mb-2">
                What are credits?
              </h3>
              <p className="text-[var(--text-secondary)]">
                Credits are used for AI photo retouching. Each photo processing consumes one credit. With annual plans, unused credits roll over to the next period.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-medium text-white mb-2">
                How long are credits valid?
              </h3>
              <p className="text-[var(--text-secondary)]">
                For pay-as-you-go plans, credits are valid for 2 years. For annual subscriptions, credits roll over and remain valid as long as your subscription is active.
              </p>
            </div>
            <div>
              <h3 className="text-lg font-medium text-white mb-2">
                What payment methods do you accept?
              </h3>
              <p className="text-[var(--text-secondary)]">
                We accept all major credit cards, including Visa, Mastercard, and American Express. Payment is processed securely through Stripe.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}