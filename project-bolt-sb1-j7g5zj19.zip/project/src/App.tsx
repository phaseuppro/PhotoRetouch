import React, { useState, useCallback, useEffect } from 'react';
import { TopMenuBar } from './components/TopMenuBar';
import { ToolBar } from './components/ToolBar';
import { ColorAdjustment } from './components/ColorAdjustment';
import { RetouchTools } from './components/RetouchTools';
import { BackgroundAdjustment } from './components/BackgroundAdjustment';
import { ClothingAdjustment } from './components/ClothingAdjustment';
import { ImageView } from './components/ImageView';
import { ImageUploader } from './components/ImageUploader';
import { Thumbnails } from './components/Thumbnails';
import { Upload, ChevronDown } from 'lucide-react';
import { supabase, getStorageFilePath, getPublicUrl } from './lib/supabase';
import { ProjectList } from './components/ProjectList';

interface Photo {
  id: string;
  original_url: string;
  processed_url: string | null;
}

interface BackgroundSettings {
  removeDistractions: boolean;
  cleanBackdrop: boolean;
  colorBanding: boolean;
  edgeAdjustment: number;
  opacity: number;
  size: number;
  vertical: number;
  horizontal: number;
}

const presets = [
  { id: 'none', name: 'No Effects' },
  { id: 'natural-01', name: 'Natural 01' },
  { id: 'natural-02', name: 'Natural 02' },
  { id: 'high-end-01', name: 'High-End 01' },
  { id: 'glowing-01', name: 'Glowing 01' },
  { id: 'glowing-02', name: 'Glowing 02' },
  { id: 'glowing-03', name: 'Glowing 03' },
  { id: 'wedding-01', name: 'Wedding 01' },
  { id: 'wedding-02', name: 'Wedding 02' },
  { id: 'wedding-03', name: 'Wedding 03' },
  { id: 'baby-01', name: 'Baby & Child 01' }
];

function App() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedTool, setSelectedTool] = useState('color');
  const [colorSettings, setColorSettings] = useState<Record<string, number>>({});
  const [backgroundSettings, setBackgroundSettings] = useState<BackgroundSettings>({
    removeDistractions: false,
    cleanBackdrop: false,
    colorBanding: false,
    edgeAdjustment: 0,
    opacity: 100,
    size: 100,
    vertical: 0,
    horizontal: 0
  });
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [selectedPhotoId, setSelectedPhotoId] = useState<string | null>(null);
  const [selectedPreset, setSelectedPreset] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [selectedProject, setSelectedProject] = useState<string | null>(null);
  const [showProjectList, setShowProjectList] = useState(true);
  const [undoStack, setUndoStack] = useState<string[]>([]);
  const [redoStack, setRedoStack] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (selectedProject) {
      loadPhotos();
      setShowProjectList(false);
    }
  }, [selectedProject]);

  const loadPhotos = async () => {
    if (!selectedProject) return;

    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('photos')
        .select('*')
        .eq('project_id', selectedProject)
        .order('created_at', { ascending: false });

      if (error) throw error;

      setPhotos(data || []);
      
      if (data && data.length > 0) {
        setSelectedPhotoId(data[0].id);
        setSelectedImage(data[0].processed_url || data[0].original_url);
      }
    } catch (error) {
      console.error('Error loading photos:', error);
      setError(error instanceof Error ? error.message : 'Failed to load photos');
    } finally {
      setIsLoading(false);
    }
  };

  const handleImageUpload = async (file: File) => {
    if (!selectedProject) {
      setError('Please select a project first');
      return;
    }

    try {
      setIsLoading(true);
      setError(null);

      // Get current user
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      if (userError) throw userError;
      if (!user) throw new Error('User not authenticated');

      // Create a unique filename
      const timestamp = Date.now();
      const fileExtension = file.name.split('.').pop();
      const fileName = `${timestamp}.${fileExtension}`;
      const filePath = getStorageFilePath(user.id, selectedProject, fileName);

      // Upload the file to storage
      const { error: uploadError } = await supabase.storage
        .from('photos')
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) throw uploadError;

      // Get the public URL
      const publicUrl = getPublicUrl(filePath);

      // Create the photo record
      const { data: photoData, error: insertError } = await supabase
        .from('photos')
        .insert([{
          project_id: selectedProject,
          original_url: publicUrl,
          processed_url: null
        }])
        .select()
        .single();

      if (insertError) throw insertError;

      // Update the UI
      const newPhoto = {
        id: photoData.id,
        original_url: publicUrl,
        processed_url: null
      };

      setPhotos(prev => [newPhoto, ...prev]);
      setSelectedPhotoId(newPhoto.id);
      setSelectedImage(publicUrl);

      // Reload photos to ensure everything is in sync
      await loadPhotos();
    } catch (error) {
      console.error('Upload error:', error);
      setError(error instanceof Error ? error.message : 'Failed to upload photo');
    } finally {
      setIsLoading(false);
    }
  };

  const handlePhotoSelect = (photoId: string) => {
    const photo = photos.find(p => p.id === photoId);
    if (photo) {
      setSelectedPhotoId(photoId);
      setSelectedImage(photo.processed_url || photo.original_url);
    }
  };

  const handleProjectSelect = (projectId: string) => {
    setSelectedProject(projectId);
    setShowProjectList(false);
  };

  const handleUndo = () => {
    if (undoStack.length > 0) {
      const previousState = undoStack[undoStack.length - 1];
      setUndoStack(prev => prev.slice(0, -1));
      setRedoStack(prev => [...prev, selectedImage!]);
      setSelectedImage(previousState);
    }
  };

  const handleRedo = () => {
    if (redoStack.length > 0) {
      const nextState = redoStack[redoStack.length - 1];
      setRedoStack(prev => prev.slice(0, -1));
      setUndoStack(prev => [...prev, selectedImage!]);
      setSelectedImage(nextState);
    }
  };

  const handleCopy = () => {
    if (selectedImage) {
      navigator.clipboard.writeText(selectedImage);
    }
  };

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text.startsWith('http')) {
        setUndoStack(prev => [...prev, selectedImage!]);
        setSelectedImage(text);
      }
    } catch (error) {
      console.error('Paste error:', error);
    }
  };

  const handleDelete = async () => {
    if (!selectedPhotoId) return;

    try {
      setIsLoading(true);
      
      // Get the photo details first
      const photo = photos.find(p => p.id === selectedPhotoId);
      if (!photo) throw new Error('Photo not found');

      // Delete from storage if URL exists
      if (photo.original_url) {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) throw new Error('User not authenticated');

        // Extract the path from the URL
        const url = new URL(photo.original_url);
        const pathParts = url.pathname.split('/');
        const filePath = pathParts[pathParts.length - 1];

        // Delete from storage
        const { error: storageError } = await supabase.storage
          .from('photos')
          .remove([`${user.id}/${selectedProject}/${filePath}`]);

        if (storageError) throw storageError;
      }

      // Delete from database
      const { error } = await supabase
        .from('photos')
        .delete()
        .eq('id', selectedPhotoId);

      if (error) throw error;

      // Update UI
      setPhotos(prev => prev.filter(p => p.id !== selectedPhotoId));
      if (photos.length > 1) {
        const nextPhoto = photos.find(p => p.id !== selectedPhotoId);
        if (nextPhoto) {
          setSelectedPhotoId(nextPhoto.id);
          setSelectedImage(nextPhoto.processed_url || nextPhoto.original_url);
        }
      } else {
        setSelectedPhotoId(null);
        setSelectedImage(null);
      }
    } catch (error) {
      console.error('Delete error:', error);
      setError(error instanceof Error ? error.message : 'Failed to delete photo');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDuplicate = async () => {
    if (!selectedPhotoId || !selectedImage) return;

    try {
      setIsLoading(true);
      const { data: photoData, error: insertError } = await supabase
        .from('photos')
        .insert([{
          project_id: selectedProject,
          original_url: selectedImage,
          processed_url: null
        }])
        .select()
        .single();

      if (insertError) throw insertError;

      const newPhoto = {
        id: photoData.id,
        original_url: selectedImage,
        processed_url: null
      };

      setPhotos(prev => [newPhoto, ...prev]);
      setSelectedPhotoId(newPhoto.id);
    } catch (error) {
      console.error('Duplicate error:', error);
      setError(error instanceof Error ? error.message : 'Failed to duplicate photo');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDownload = () => {
    if (selectedImage) {
      const link = document.createElement('a');
      link.href = selectedImage;
      link.download = 'photo.jpg';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };

  const handleShare = () => {
    if (selectedImage) {
      if (navigator.share) {
        navigator.share({
          title: 'Share Photo',
          url: selectedImage
        }).catch(console.error);
      } else {
        navigator.clipboard.writeText(selectedImage)
          .then(() => alert('Link copied to clipboard!'))
          .catch(console.error);
      }
    }
  };

  const handleBackgroundSettingChange = (setting: string, value: boolean | number) => {
    setBackgroundSettings(prev => ({
      ...prev,
      [setting]: value
    }));
  };

  const getToolTitle = (tool: string) => {
    switch (tool) {
      case 'color':
        return 'Color Adjustment';
      case 'portrait':
        return 'Portrait Retouching';
      case 'background':
        return 'Background Adjustment';
      case 'clothing':
        return 'Clothing Adjustment';
      case 'crop':
        return 'Crop & Rotate';
      default:
        return '';
    }
  };

  const renderToolPanel = () => {
    const toolTitle = getToolTitle(selectedTool);

    return (
      <div className="h-full flex flex-col">
        {toolTitle && (
          <div className="bg-[var(--accent-color)] px-4 py-3">
            <h2 className="text-black font-medium">{toolTitle}</h2>
          </div>
        )}
        <div className="flex-1 overflow-y-auto">
          {(() => {
            switch (selectedTool) {
              case 'color':
                return (
                  <ColorAdjustment
                    settings={colorSettings}
                    onSettingChange={(setting, value) => {
                      setColorSettings(prev => ({ ...prev, [setting]: value }));
                    }}
                  />
                );
              case 'portrait':
                return <RetouchTools />;
              case 'background':
                return (
                  <BackgroundAdjustment
                    onBackdropSelect={() => {}}
                    onSkySelect={() => {}}
                    settings={backgroundSettings}
                    onSettingChange={handleBackgroundSettingChange}
                  />
                );
              case 'clothing':
                return (
                  <ClothingAdjustment
                    settings={colorSettings}
                    onSettingChange={(setting, value) => {
                      setColorSettings(prev => ({ ...prev, [setting]: value }));
                    }}
                    selectedSubject="female"
                    onSubjectSelect={() => {}}
                  />
                );
              default:
                return null;
            }
          })()}
        </div>
      </div>
    );
  };

  if (showProjectList) {
    return <ProjectList onProjectSelect={handleProjectSelect} />;
  }

  return (
    <div className="h-screen flex flex-col bg-[var(--app-bg)]">
      <TopMenuBar
        onUndo={handleUndo}
        onRedo={handleRedo}
        onCopy={handleCopy}
        onPaste={handlePaste}
        onDelete={handleDelete}
        onDuplicate={handleDuplicate}
        onDownload={handleDownload}
        onShare={handleShare}
        onBack={() => setShowProjectList(true)}
        canUndo={undoStack.length > 0}
        canRedo={redoStack.length > 0}
        hasPreviousPhoto={false}
        hasNextPhoto={false}
      />
      
      <div className="flex-1 flex min-h-0">
        {/* Left Sidebar - Presets */}
        <div className="w-64 bg-[var(--panel-bg)] border-r border-[var(--border-color)] flex flex-col">
          <div className="p-3 border-b border-[var(--border-color)]">
            <h2 className="text-[11px] font-medium text-[var(--text-secondary)] mb-2">Presets</h2>
            <div className="flex space-x-1 mb-2">
              <button className="flex-1 px-2 py-1 text-[11px] bg-[var(--accent-color)] text-black rounded">
                Recommended
              </button>
              <button className="flex-1 px-2 py-1 text-[11px] text-[var(--text-secondary)] hover:bg-[var(--hover-bg)] rounded">
                My Presets
              </button>
            </div>
            <button className="w-full flex items-center justify-between px-2 py-1.5 text-[11px] text-[var(--text-secondary)] bg-[#1a1a1a] rounded hover:bg-[var(--hover-bg)]">
              <span>All Presets</span>
              <ChevronDown className="w-3.5 h-3.5" />
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto p-2 space-y-1">
            {presets.map(preset => (
              <button
                key={preset.id}
                onClick={() => setSelectedPreset(preset.id)}
                className={`w-full px-2 py-1.5 text-left text-[11px] rounded ${
                  selectedPreset === preset.id
                    ? 'bg-[var(--accent-color)] text-black'
                    : 'text-[var(--text-secondary)] hover:bg-[var(--hover-bg)]'
                }`}
              >
                {preset.name}
              </button>
            ))}
          </div>
        </div>

        {/* Main Canvas */}
        <div className="flex-1 flex flex-col min-w-0">
          <div className="flex-1 flex items-center justify-center relative">
            {isLoading ? (
              <div className="text-[var(--text-secondary)]">Loading...</div>
            ) : (
              <ImageView 
                image={selectedImage} 
                onUpload={handleImageUpload}
              />
            )}

            {error && (
              <div className="absolute top-4 right-4 bg-red-500/10 border border-red-500 text-red-500 px-4 py-2 rounded-md">
                {error}
              </div>
            )}
          </div>

          {/* Thumbnails */}
          <div className="h-28 bg-[var(--panel-bg)] border-t border-[var(--border-color)]">
            <Thumbnails
              photos={photos}
              selectedPhotoId={selectedPhotoId}
              onPhotoSelect={handlePhotoSelect}
              onUpload={handleImageUpload}
            />
          </div>
        </div>

        {/* Right Panel */}
        <div className="flex">
          <div className="w-80 bg-[var(--panel-bg)] border-l border-[var(--border-color)] overflow-hidden">
            {renderToolPanel()}
          </div>
          <div className="w-12 bg-[var(--panel-bg)] border-l border-[var(--border-color)]">
            <ToolBar selectedTool={selectedTool} onToolSelect={setSelectedTool} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;