import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

interface Subscription {
  id: string;
  status: 'active' | 'canceled' | 'past_due';
  current_period_end: string;
}

interface Tokens {
  amount: number;
}

export function useSubscription() {
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [tokens, setTokens] = useState<Tokens | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadSubscriptionData() {
      try {
        // Get current user
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) throw new Error('No authenticated user');

        // Load subscription data
        const { data: subscriptionData, error: subscriptionError } = await supabase
          .from('subscriptions')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();

        if (subscriptionError) throw subscriptionError;
        setSubscription(subscriptionData);

        // Load or initialize tokens
        const { data: existingTokens, error: tokensError } = await supabase
          .from('tokens')
          .select('amount')
          .eq('user_id', user.id)
          .maybeSingle();

        if (tokensError) throw tokensError;

        if (existingTokens) {
          setTokens(existingTokens);
        } else {
          // Only try to create if no tokens record exists
          const { data: newTokens, error: createError } = await supabase
            .from('tokens')
            .upsert([{ user_id: user.id, amount: 0 }], { 
              onConflict: 'user_id',
              ignoreDuplicates: true 
            })
            .select('amount')
            .single();

          if (createError) throw createError;
          setTokens(newTokens);
        }
      } catch (err) {
        console.error('Subscription data error:', err);
        setError(err instanceof Error ? err.message : 'Failed to load subscription data');
      } finally {
        setIsLoading(false);
      }
    }

    loadSubscriptionData();
  }, []);

  return { subscription, tokens, isLoading, error };
}