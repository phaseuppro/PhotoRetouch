import React from 'react';
import { CreditCard, Coins } from 'lucide-react';
import { useSubscription } from '../hooks/useSubscription';

export const SubscriptionStatus: React.FC = () => {
  const { subscription, tokens, isLoading, error } = useSubscription();

  if (isLoading) {
    return (
      <div className="animate-pulse flex items-center space-x-2 p-3">
        <div className="h-3 bg-gray-700 rounded w-20"></div>
        <div className="h-3 bg-gray-700 rounded w-10"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-red-500 p-3 text-sm">
        {error}
      </div>
    );
  }

  return (
    <div className="p-3 bg-[var(--panel-bg)] border-t border-[var(--border-color)] text-xs">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center space-x-1.5 text-[var(--text-secondary)]">
          <CreditCard className="w-3.5 h-3.5 text-[var(--accent-color)]" />
          <span>{subscription?.status === 'active' ? 'Active Plan' : 'No Plan'}</span>
        </div>
        {!subscription && (
          <button className="text-[var(--accent-color)] hover:underline">
            Subscribe
          </button>
        )}
      </div>
      <div className="flex items-center space-x-1.5 text-[var(--text-secondary)]">
        <Coins className="w-3.5 h-3.5 text-yellow-500" />
        <span>{tokens?.amount || 0} tokens left</span>
      </div>
    </div>
  );
}