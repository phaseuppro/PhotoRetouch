import React from 'react';
import { ImageUploader } from './ImageUploader';
import { Upload } from 'lucide-react';

interface Photo {
  id: string;
  original_url: string;
  processed_url: string | null;
}

interface ThumbnailsProps {
  photos: Photo[];
  selectedPhotoId: string | null;
  onPhotoSelect: (photoId: string) => void;
  onUpload: (file: File) => void;
}

export const Thumbnails: React.FC<ThumbnailsProps> = ({
  photos,
  selectedPhotoId,
  onPhotoSelect,
  onUpload
}) => {
  const handleImageError = (e: React.SyntheticEvent<HTMLImageElement, Event>, photo: Photo) => {
    const img = e.target as HTMLImageElement;
    const currentSrc = img.src;
    
    // If processed_url failed, try original_url
    if (photo.processed_url && currentSrc === photo.processed_url) {
      img.src = photo.original_url;
    }
  };

  return (
    <div className="h-full flex items-center px-4">
      <div className="flex space-x-2 overflow-x-auto py-2">
        <ImageUploader onUpload={onUpload}>
          <button 
            className="flex-shrink-0 w-20 h-20 flex items-center justify-center rounded-lg border-2 border-dashed border-[var(--border-color)] hover:border-[var(--accent-color)] hover:bg-[var(--accent-color)]/5 transition-colors group"
            title="Upload new photo"
          >
            <Upload className="w-6 h-6 text-[var(--text-secondary)] group-hover:text-[var(--accent-color)]" />
          </button>
        </ImageUploader>

        {photos.map((photo) => (
          <button
            key={photo.id}
            onClick={() => onPhotoSelect(photo.id)}
            className={`flex-shrink-0 relative rounded-lg overflow-hidden border-2 transition-all ${
              selectedPhotoId === photo.id
                ? 'border-[var(--accent-color)] shadow-lg scale-105'
                : 'border-transparent hover:border-[var(--border-color)] hover:scale-105'
            }`}
          >
            <div className="w-20 h-20 bg-[var(--panel-bg)]">
              <img
                src={photo.processed_url || photo.original_url}
                alt="Thumbnail"
                className="w-full h-full object-cover"
                loading="lazy"
                onError={(e) => handleImageError(e, photo)}
              />
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};