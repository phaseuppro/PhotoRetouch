import React from 'react';
import { 
  UserCircle2, Palette, Image, Shirt, 
  Crop, Sliders, SunMoon, Layers
} from 'lucide-react';

export type ToolCategory = 
  | 'portrait'
  | 'color'
  | 'background'
  | 'clothing'
  | 'crop'
  | 'effects';

interface ToolSelectorProps {
  selectedCategory: ToolCategory;
  onCategorySelect: (category: ToolCategory) => void;
}

export const ToolSelector: React.FC<ToolSelectorProps> = ({
  selectedCategory,
  onCategorySelect,
}) => {
  const categories = [
    {
      id: 'portrait' as ToolCategory,
      icon: UserCircle2,
      tooltip: 'Portrait Retouching'
    },
    {
      id: 'color' as ToolCategory,
      icon: Palette,
      tooltip: 'Color Adjustment'
    },
    {
      id: 'background' as ToolCategory,
      icon: Image,
      tooltip: 'Background Adjustment'
    },
    {
      id: 'clothing' as ToolCategory,
      icon: Shirt,
      tooltip: 'Clothing Adjustment'
    },
    {
      id: 'crop' as ToolCategory,
      icon: Crop,
      tooltip: 'Crop & Rotate'
    },
    {
      id: 'effects' as ToolCategory,
      icon: Layers,
      tooltip: 'Effects'
    }
  ];

  return (
    <div className="tool-selector">
      {categories.map((category) => (
        <button
          key={category.id}
          onClick={() => onCategorySelect(category.id)}
          className={`tool-category-button ${selectedCategory === category.id ? 'active' : ''}`}
          title={category.tooltip}
        >
          <category.icon className="w-5 h-5" />
        </button>
      ))}
    </div>
  );
};