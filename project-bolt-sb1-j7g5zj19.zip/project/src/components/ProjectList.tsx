import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { Folder, Plus, Image as ImageIcon, Pencil, Trash2, X, Check } from 'lucide-react';

interface Project {
  id: string;
  name: string;
  created_at: string;
}

export function ProjectList({ onProjectSelect }: { onProjectSelect: (projectId: string) => void }) {
  const [projects, setProjects] = useState<Project[]>([]);
  const [newProjectName, setNewProjectName] = useState('');
  const [isCreating, setIsCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [isDeletingId, setIsDeletingId] = useState<string | null>(null);

  useEffect(() => {
    loadProjects();
  }, []);

  async function loadProjects() {
    const { data, error } = await supabase
      .from('projects')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      setError(error.message);
    } else {
      setProjects(data || []);
    }
  }

  async function createProject(e: React.FormEvent) {
    e.preventDefault();
    if (!newProjectName.trim()) return;

    const {
      data: { user },
    } = await supabase.auth.getUser();

    if (!user) {
      setError('You must be logged in to create a project');
      return;
    }

    const { data, error } = await supabase
      .from('projects')
      .insert([{ 
        name: newProjectName,
        user_id: user.id
      }])
      .select()
      .single();

    if (error) {
      setError(error.message);
    } else if (data) {
      setProjects([data, ...projects]);
      setNewProjectName('');
      setIsCreating(false);
    }
  }

  async function renameProject(projectId: string) {
    if (!editName.trim()) return;

    const { error } = await supabase
      .from('projects')
      .update({ name: editName })
      .eq('id', projectId);

    if (error) {
      setError(error.message);
    } else {
      setProjects(projects.map(p => 
        p.id === projectId ? { ...p, name: editName } : p
      ));
      setEditingId(null);
      setEditName('');
    }
  }

  async function deleteProject(projectId: string) {
    const { error } = await supabase
      .from('projects')
      .delete()
      .eq('id', projectId);

    if (error) {
      setError(error.message);
    } else {
      setProjects(projects.filter(p => p.id !== projectId));
      setIsDeletingId(null);
    }
  }

  function startEditing(project: Project) {
    setEditingId(project.id);
    setEditName(project.name);
  }

  return (
    <div className="p-4">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-xl font-semibold text-white">Your Projects</h2>
        <button
          onClick={() => setIsCreating(true)}
          className="flex items-center px-3 py-1.5 bg-purple-600 text-white rounded hover:bg-purple-700 transition-colors"
        >
          <Plus className="w-4 h-4 mr-2" />
          New Project
        </button>
      </div>

      {error && (
        <div className="bg-red-500/10 border border-red-500 text-red-500 px-4 py-2 rounded mb-4">
          {error}
        </div>
      )}

      {isCreating && (
        <form onSubmit={createProject} className="mb-6">
          <div className="flex gap-2">
            <input
              type="text"
              value={newProjectName}
              onChange={(e) => setNewProjectName(e.target.value)}
              placeholder="Project name"
              className="flex-1 px-3 py-2 bg-[#1a1d1e] border border-gray-700 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-purple-500"
              autoFocus
            />
            <button
              type="submit"
              className="px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700 transition-colors"
            >
              Create
            </button>
            <button
              type="button"
              onClick={() => setIsCreating(false)}
              className="px-4 py-2 bg-gray-700 text-white rounded hover:bg-gray-600 transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {projects.map((project) => (
          <div
            key={project.id}
            className="group bg-[#2a2d2e] rounded-lg p-4 hover:bg-[#3a3d3e] transition-colors"
          >
            {editingId === project.id ? (
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="flex-1 px-2 py-1 bg-[#1a1d1e] border border-gray-700 rounded text-white text-sm focus:outline-none focus:ring-2 focus:ring-purple-500"
                  autoFocus
                />
                <button
                  onClick={() => renameProject(project.id)}
                  className="p-1 text-green-500 hover:bg-green-500/10 rounded"
                >
                  <Check className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setEditingId(null)}
                  className="p-1 text-gray-400 hover:bg-gray-500/10 rounded"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-start justify-between">
                <button
                  onClick={() => onProjectSelect(project.id)}
                  className="flex items-center space-x-3 text-left flex-1"
                >
                  <Folder className="w-6 h-6 text-purple-500 flex-shrink-0" />
                  <div className="min-w-0">
                    <h3 className="text-white font-medium truncate">{project.name}</h3>
                    <p className="text-sm text-gray-400">
                      {new Date(project.created_at).toLocaleDateString()}
                    </p>
                  </div>
                </button>
                <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={() => startEditing(project)}
                    className="p-1 text-gray-400 hover:text-white hover:bg-gray-500/20 rounded"
                    title="Rename project"
                  >
                    <Pencil className="w-4 h-4" />
                  </button>
                  {isDeletingId === project.id ? (
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => deleteProject(project.id)}
                        className="p-1 text-red-500 hover:bg-red-500/10 rounded"
                        title="Confirm delete"
                      >
                        <Check className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setIsDeletingId(null)}
                        className="p-1 text-gray-400 hover:bg-gray-500/10 rounded"
                        title="Cancel"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setIsDeletingId(project.id)}
                      className="p-1 text-gray-400 hover:text-red-500 hover:bg-red-500/10 rounded"
                      title="Delete project"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {projects.length === 0 && !isCreating && (
        <div className="text-center py-12">
          <ImageIcon className="w-12 h-12 text-gray-500 mx-auto mb-4" />
          <p className="text-gray-400">No projects yet. Create your first project to get started!</p>
        </div>
      )}
    </div>
  );
}