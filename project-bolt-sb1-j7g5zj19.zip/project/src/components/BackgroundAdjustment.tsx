import React, { useState } from 'react';
import { Trash2, Image, Wand2, ChevronDown } from 'lucide-react';
import { Tooltip } from './Tooltip';

interface BackgroundAdjustmentProps {
  onBackdropSelect: (backdropId: string) => void;
  onSkySelect: (skyId: string) => void;
  settings: {
    removeDistractions: boolean;
    cleanBackdrop: boolean;
    colorBanding: boolean;
    edgeAdjustment: number;
    opacity: number;
    size: number;
    vertical: number;
    horizontal: number;
  };
  onSettingChange: (setting: string, value: boolean | number) => void;
}

export const BackgroundAdjustment: React.FC<BackgroundAdjustmentProps> = ({
  onBackdropSelect,
  settings,
  onSettingChange,
}) => {
  const [expandedSection, setExpandedSection] = useState<string | null>('refinement');

  const backdrops = [
    { id: 'white', url: 'https://images.unsplash.com/photo-1533628635777-112b2239b1c7?w=120&h=120&fit=crop&q=80' },
    { id: 'black', url: 'https://images.unsplash.com/photo-1533628635777-112b2239b1c7?w=120&h=120&fit=crop&q=80' },
    { id: 'gray', url: 'https://images.unsplash.com/photo-1533628635777-112b2239b1c7?w=120&h=120&fit=crop&q=80' },
    { id: 'beige', url: 'https://images.unsplash.com/photo-1533628635777-112b2239b1c7?w=120&h=120&fit=crop&q=80' },
    { id: 'blue', url: 'https://images.unsplash.com/photo-1533628635777-112b2239b1c7?w=120&h=120&fit=crop&q=80' },
    { id: 'green', url: 'https://images.unsplash.com/photo-1533628635777-112b2239b1c7?w=120&h=120&fit=crop&q=80' },
    { id: 'pink', url: 'https://images.unsplash.com/photo-1533628635777-112b2239b1c7?w=120&h=120&fit=crop&q=80' },
    { id: 'purple', url: 'https://images.unsplash.com/photo-1533628635777-112b2239b1c7?w=120&h=120&fit=crop&q=80' },
  ];

  const toggleSection = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  return (
    <div className="p-2 space-y-2">
      {/* Solid Backdrop Refinement */}
      <div className="rounded-lg overflow-hidden bg-black">
        <button
          onClick={() => toggleSection('refinement')}
          className="w-full px-4 py-3 flex items-center justify-between text-white hover:bg-white/5 transition-colors"
        >
          <div className="flex items-center">
            <Wand2 className="w-4 h-4 mr-2" />
            <span className="text-sm font-medium">Solid Backdrop Refinement</span>
          </div>
          <ChevronDown
            className={`w-4 h-4 transition-transform ${
              expandedSection === 'refinement' ? 'rotate-180' : ''
            }`}
          />
        </button>
        
        {expandedSection === 'refinement' && (
          <div className="px-4 py-4 space-y-4 bg-[#2f2f2f]">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Trash2 className="w-4 h-4 mr-2 text-[var(--text-secondary)]" />
                <span className="text-sm">Remove Distractions</span>
                <Tooltip
                  title="Remove Distractions"
                  content="Automatically detect and remove unwanted elements from the background like poles, wires, or random objects."
                />
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.removeDistractions}
                  onChange={(e) => onSettingChange('removeDistractions', e.target.checked)}
                  className="sr-only peer"
                  id="remove-distractions"
                />
                <div className="w-9 h-5 bg-[var(--border-color)] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[var(--accent-color)]"></div>
              </label>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Wand2 className="w-4 h-4 mr-2 text-[var(--text-secondary)]" />
                <span className="text-sm">Clean Backdrop</span>
                <Tooltip
                  title="Clean Backdrop"
                  content="Smooth out backdrop imperfections while preserving natural texture. Perfect for studio-like results."
                />
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.cleanBackdrop}
                  onChange={(e) => onSettingChange('cleanBackdrop', e.target.checked)}
                  className="sr-only peer"
                  id="clean-backdrop"
                />
                <div className="w-9 h-5 bg-[var(--border-color)] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[var(--accent-color)]"></div>
              </label>
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Image className="w-4 h-4 mr-2 text-[var(--text-secondary)]" />
                <span className="text-sm">Remove Color Banding</span>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.colorBanding}
                  onChange={(e) => onSettingChange('colorBanding', e.target.checked)}
                  className="sr-only peer"
                  id="color-banding"
                />
                <div className="w-9 h-5 bg-[var(--border-color)] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[var(--accent-color)]"></div>
              </label>
            </div>
          </div>
        )}
      </div>

      {/* Backdrop Changer */}
      <div className="rounded-lg overflow-hidden bg-black">
        <button
          onClick={() => toggleSection('changer')}
          className="w-full px-4 py-3 flex items-center justify-between text-white hover:bg-white/5 transition-colors"
        >
          <div className="flex items-center">
            <Image className="w-4 h-4 mr-2" />
            <span className="text-sm font-medium">Backdrop Changer</span>
          </div>
          <ChevronDown
            className={`w-4 h-4 transition-transform ${
              expandedSection === 'changer' ? 'rotate-180' : ''
            }`}
          />
        </button>

        {expandedSection === 'changer' && (
          <div className="px-4 py-4 bg-[#2f2f2f]">
            {/* Backdrop Grid */}
            <div className="grid grid-cols-4 gap-2 mb-4">
              {backdrops.map((backdrop) => (
                <button
                  key={backdrop.id}
                  onClick={() => onBackdropSelect(backdrop.id)}
                  className="aspect-square rounded-lg overflow-hidden hover:ring-2 hover:ring-[var(--accent-color)] transition-all"
                >
                  <img
                    src={backdrop.url}
                    alt={`${backdrop.id} backdrop`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>

            {/* Adjustment Sliders */}
            <div className="space-y-4">
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <div className="flex items-center gap-2">
                    <span>Edge Adjustment</span>
                    <Tooltip
                      title="Edge Adjustment"
                      content="Fine-tune the transition between subject and background. Higher values create smoother edges, lower values maintain more detail."
                    />
                  </div>
                  <span className="text-[var(--text-secondary)]">{settings.edgeAdjustment}</span>
                </div>
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-[var(--accent-color)] to-transparent rounded-full opacity-10" style={{ width: `${settings.edgeAdjustment}%` }}></div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={settings.edgeAdjustment}
                    onChange={(e) => onSettingChange('edgeAdjustment', parseInt(e.target.value))}
                    className="w-full h-[3px] bg-[var(--border-color)] rounded-full appearance-none cursor-pointer relative z-10"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span>Opacity</span>
                  <span className="text-[var(--text-secondary)]">{settings.opacity}%</span>
                </div>
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-[var(--accent-color)] to-transparent rounded-full opacity-10" style={{ width: `${settings.opacity}%` }}></div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={settings.opacity}
                    onChange={(e) => onSettingChange('opacity', parseInt(e.target.value))}
                    className="w-full h-[3px] bg-[var(--border-color)] rounded-full appearance-none cursor-pointer relative z-10"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span>Size</span>
                  <span className="text-[var(--text-secondary)]">{settings.size}%</span>
                </div>
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-[var(--accent-color)] to-transparent rounded-full opacity-10" style={{ width: `${((settings.size - 50) / 100) * 100}%` }}></div>
                  <input
                    type="range"
                    min="50"
                    max="150"
                    value={settings.size}
                    onChange={(e) => onSettingChange('size', parseInt(e.target.value))}
                    className="w-full h-[3px] bg-[var(--border-color)] rounded-full appearance-none cursor-pointer relative z-10"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span>Vertical Position</span>
                  <span className="text-[var(--text-secondary)]">{settings.vertical}</span>
                </div>
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-[var(--accent-color)] to-transparent rounded-full opacity-10" style={{ width: `${((settings.vertical + 100) / 200) * 100}%` }}></div>
                  <input
                    type="range"
                    min="-100"
                    max="100"
                    value={settings.vertical}
                    onChange={(e) => onSettingChange('vertical', parseInt(e.target.value))}
                    className="w-full h-[3px] bg-[var(--border-color)] rounded-full appearance-none cursor-pointer relative z-10"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span>Horizontal Position</span>
                  <span className="text-[var(--text-secondary)]">{settings.horizontal}</span>
                </div>
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-[var(--accent-color)] to-transparent rounded-full opacity-10" style={{ width: `${((settings.horizontal + 100) / 200) * 100}%` }}></div>
                  <input
                    type="range"
                    min="-100"
                    max="100"
                    value={settings.horizontal}
                    onChange={(e) => onSettingChange('horizontal', parseInt(e.target.value))}
                    className="w-full h-[3px] bg-[var(--border-color)] rounded-full appearance-none cursor-pointer relative z-10"
                  />
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};