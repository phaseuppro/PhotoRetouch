import React, { useEffect, useRef } from 'react';
import * as d3 from 'd3';

interface HistogramProps {
  data?: number[];
  width?: number;
  height?: number;
  showRGB?: boolean;
}

export const Histogram: React.FC<HistogramProps> = ({
  data = [],
  width = 250,
  height = 100,
  showRGB = true
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, width, height);

    // If no data, generate sample data for visualization
    const sampleData = data.length ? data : Array.from({ length: 256 }, () => 
      Math.random() * 100 + Math.sin(Math.random() * Math.PI) * 50
    );

    // Create scales
    const xScale = d3.scaleLinear()
      .domain([0, 255])
      .range([0, width]);

    const yScale = d3.scaleLinear()
      .domain([0, d3.max(sampleData) || 100])
      .range([height, 0]);

    // Draw RGB histograms
    if (showRGB) {
      // Red channel
      ctx.beginPath();
      ctx.strokeStyle = 'rgba(255,0,0,0.5)';
      sampleData.forEach((d, i) => {
        ctx.lineTo(xScale(i), yScale(d * 0.8));
      });
      ctx.stroke();

      // Green channel
      ctx.beginPath();
      ctx.strokeStyle = 'rgba(0,255,0,0.5)';
      sampleData.forEach((d, i) => {
        ctx.lineTo(xScale(i), yScale(d * 0.9));
      });
      ctx.stroke();

      // Blue channel
      ctx.beginPath();
      ctx.strokeStyle = 'rgba(0,0,255,0.5)';
      sampleData.forEach((d, i) => {
        ctx.lineTo(xScale(i), yScale(d));
      });
      ctx.stroke();
    } else {
      // Luminance histogram
      ctx.beginPath();
      ctx.strokeStyle = 'rgba(255,255,255,0.5)';
      sampleData.forEach((d, i) => {
        ctx.lineTo(xScale(i), yScale(d));
      });
      ctx.stroke();
    }

  }, [data, width, height, showRGB]);

  return (
    <canvas
      ref={canvasRef}
      width={width}
      height={height}
      className="bg-[#1a1a1a] rounded-lg"
    />
  );
};