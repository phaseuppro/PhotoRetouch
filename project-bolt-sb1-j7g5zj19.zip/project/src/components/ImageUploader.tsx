import React, { useCallback, ReactNode, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, AlertCircle } from 'lucide-react';

interface ImageUploaderProps {
  onUpload: (file: File) => void;
  children?: ReactNode;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({ onUpload, children }) => {
  const [error, setError] = useState<string | null>(null);

  const validateFile = (file: File) => {
    // Check file size (max 10MB)
    const maxSize = 10 * 1024 * 1024;
    if (file.size > maxSize) {
      throw new Error('Image size must be less than 10MB');
    }

    // Check file type
    const validTypes = ['image/jpeg', 'image/png', 'image/jpg'];
    if (!validTypes.includes(file.type)) {
      throw new Error('Only JPG and PNG images are allowed');
    }

    // Check dimensions (optional)
    return new Promise<void>((resolve, reject) => {
      const img = new Image();
      const objectUrl = URL.createObjectURL(file);
      
      img.onload = () => {
        URL.revokeObjectURL(objectUrl);
        if (img.width < 200 || img.height < 200) {
          reject(new Error('Image dimensions must be at least 200x200 pixels'));
        }
        resolve();
      };
      
      img.onerror = () => {
        URL.revokeObjectURL(objectUrl);
        reject(new Error('Failed to load image'));
      };
      
      img.src = objectUrl;
    });
  };

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      const file = acceptedFiles[0];
      try {
        setError(null);
        await validateFile(file);
        onUpload(file);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to process image');
      }
    }
  }, [onUpload]);

  const { getRootProps, getInputProps, isDragActive, isDragReject } = useDropzone({
    onDrop,
    accept: {
      'image/jpeg': ['.jpg', '.jpeg'],
      'image/png': ['.png']
    },
    multiple: false,
    maxSize: 10 * 1024 * 1024, // 10MB
    noClick: !!children,
    noKeyboard: !!children,
    noDrag: !!children
  });

  if (children) {
    return (
      <div {...getRootProps()} className="relative">
        <input {...getInputProps()} />
        {children}
        {error && (
          <div className="absolute top-full left-0 mt-2 px-3 py-2 bg-red-500/10 border border-red-500 text-red-500 text-sm rounded-lg">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4" />
              <span>{error}</span>
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="relative">
      <div
        {...getRootProps()}
        className={`w-full h-full flex items-center justify-center p-8 border-2 border-dashed rounded-lg transition-colors ${
          isDragActive
            ? 'border-[var(--accent-color)] bg-[var(--accent-color)]/5'
            : isDragReject
            ? 'border-red-500 bg-red-500/5'
            : error
            ? 'border-red-500'
            : 'border-[var(--border-color)] hover:border-[var(--accent-color)] hover:bg-[var(--accent-color)]/5'
        }`}
      >
        <input {...getInputProps()} />
        <div className="text-center">
          <div className="flex items-center justify-center mb-2">
            <Upload className={`w-8 h-8 ${
              isDragActive
                ? 'text-[var(--accent-color)]'
                : isDragReject
                ? 'text-red-500'
                : 'text-[var(--text-secondary)]'
            }`} />
          </div>
          <p className={`text-sm ${
            isDragActive
              ? 'text-[var(--accent-color)]'
              : isDragReject
              ? 'text-red-500'
              : 'text-[var(--text-secondary)]'
          }`}>
            {isDragActive
              ? 'Drop the image here'
              : isDragReject
              ? 'This file type is not supported'
              : 'Drag & drop an image here, or click to select'}
          </p>
          <p className="text-xs text-[var(--text-secondary)] mt-2">
            Supports: JPG, PNG • Max size: 10MB
          </p>
        </div>
      </div>

      {error && (
        <div className="absolute top-full left-0 right-0 mt-2 px-3 py-2 bg-red-500/10 border border-red-500 text-red-500 text-sm rounded-lg">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4" />
            <span>{error}</span>
          </div>
        </div>
      )}
    </div>
  );
};