import React, { useState, useRef } from 'react';
import { Info } from 'lucide-react';

interface TooltipProps {
  title: string;
  content: string;
  children?: React.ReactNode;
  icon?: boolean;
}

export const Tooltip: React.FC<TooltipProps> = ({
  title,
  content,
  children,
  icon = true
}) => {
  const [isVisible, setIsVisible] = useState(false);
  const tooltipRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  const calculatePosition = () => {
    if (!tooltipRef.current || !contentRef.current) return {};

    const tooltipRect = tooltipRef.current.getBoundingClientRect();
    const contentRect = contentRef.current.getBoundingClientRect();
    const viewportWidth = window.innerWidth;

    // Calculate the center position
    let left = tooltipRect.left + (tooltipRect.width / 2) - (contentRect.width / 2);
    
    // Ensure the tooltip doesn't go off-screen
    if (left < 10) left = 10;
    if (left + contentRect.width > viewportWidth - 10) {
      left = viewportWidth - contentRect.width - 10;
    }

    return {
      left: `${left}px`,
      top: `${tooltipRect.bottom + 5}px`
    };
  };

  return (
    <div 
      className="relative inline-flex items-center" 
      ref={tooltipRef}
      onMouseEnter={() => setIsVisible(true)}
      onMouseLeave={() => setIsVisible(false)}
    >
      {children || (icon && (
        <Info className="w-3.5 h-3.5 text-[var(--text-secondary)] hover:text-white" />
      ))}
      
      {isVisible && (
        <div 
          ref={contentRef}
          className="fixed z-50 w-64 bg-[var(--accent-color)] rounded-lg shadow-lg p-3 text-white text-xs"
          style={calculatePosition()}
        >
          {/* Arrow */}
          <div 
            className="absolute w-3 h-3 bg-[var(--accent-color)] rotate-45"
            style={{
              left: '50%',
              transform: 'translateX(-50%)',
              top: '-6px'
            }}
          />
          
          <div className="relative">
            <div className="font-medium mb-1">{title}</div>
            <div className="text-white/80">{content}</div>
          </div>
        </div>
      )}
    </div>
  );
};