import React, { useState, useEffect, useRef } from 'react';
import { ChevronDown, Sliders, Sun, Contrast, LineChart, Focus, Palette, Droplet } from 'lucide-react';
import { CurveEditor } from './CurveEditor';
import { Histogram } from './Histogram';
import { Tooltip } from './Tooltip';

interface ColorAdjustmentProps {
  settings: Record<string, number>;
  onSettingChange: (setting: string, value: number) => void;
}

const ColorAdjustment: React.FC<ColorAdjustmentProps> = ({
  settings,
  onSettingChange,
}) => {
  const [expandedSection, setExpandedSection] = useState<string | null>('basic');
  const [whiteBalance, setWhiteBalance] = useState<'as-shot' | 'auto' | 'custom'>('as-shot');
  const [selectedChannel, setSelectedChannel] = useState<'rgb' | 'r' | 'g' | 'b'>('rgb');
  const [curvePoints, setCurvePoints] = useState<{ [key: string]: { x: number; y: number; }[] }>({
    rgb: [
      { x: 0, y: 0 },
      { x: 0.25, y: 0.25 },
      { x: 0.5, y: 0.5 },
      { x: 0.75, y: 0.75 },
      { x: 1, y: 1 }
    ],
    r: [
      { x: 0, y: 0 },
      { x: 0.5, y: 0.5 },
      { x: 1, y: 1 }
    ],
    g: [
      { x: 0, y: 0 },
      { x: 0.5, y: 0.5 },
      { x: 1, y: 1 }
    ],
    b: [
      { x: 0, y: 0 },
      { x: 0.5, y: 0.5 },
      { x: 1, y: 1 }
    ]
  });

  const toggleSection = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  const handleCurveChange = (channel: 'rgb' | 'r' | 'g' | 'b', points: { x: number; y: number; }[]) => {
    setCurvePoints(prev => ({
      ...prev,
      [channel]: points
    }));
  };

  return (
    <div className="p-2 space-y-2">
      {/* Histogram Section - Always visible */}
      <div className="rounded-lg overflow-hidden bg-black">
        <div className="px-4 py-3 flex items-center justify-between text-white">
          <span className="text-sm font-medium">Histogram</span>
        </div>
        <div className="px-4 py-4 bg-[#2f2f2f]">
          <div className="bg-[#1a1a1a] rounded-md overflow-hidden">
            <div className="flex items-center justify-between px-2 py-1 bg-black/30 border-b border-[var(--border-color)] text-[10px]">
              <div className="flex items-center space-x-3 text-[var(--text-secondary)]">
                <span>ISO 100</span>
                <span>50mm</span>
                <span>ƒ/2.8</span>
                <span>1/125s</span>
              </div>
              <span className="text-[var(--text-secondary)]">JPG</span>
            </div>
            
            <div className="p-2">
              <Histogram width={200} height={80} showRGB={true} />
              <div className="flex justify-between mt-1 text-[10px] text-[var(--text-secondary)]">
                <span>0</span>
                <span>255</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Basic Controls */}
      <div className="rounded-lg overflow-hidden bg-black">
        <button
          onClick={() => toggleSection('basic')}
          className="w-full px-4 py-3 flex items-center justify-between text-white hover:bg-white/5 transition-colors"
        >
          <div className="flex items-center">
            <Sliders className="w-4 h-4 mr-2" />
            <span className="text-sm font-medium">Basic</span>
          </div>
          <ChevronDown
            className={`w-4 h-4 transition-transform ${
              expandedSection === 'basic' ? 'rotate-180' : ''
            }`}
          />
        </button>

        {expandedSection === 'basic' && (
          <div className="px-4 py-4 space-y-6 bg-[#2f2f2f]">
            {/* White Balance Section */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">White Balance</span>
                <select
                  value={whiteBalance}
                  onChange={(e) => setWhiteBalance(e.target.value as 'as-shot' | 'auto' | 'custom')}
                  className="bg-[#1a1a1a] border border-[var(--border-color)] rounded px-2 py-1 text-sm"
                >
                  <option value="as-shot">As Shot</option>
                  <option value="auto">Auto</option>
                  <option value="custom">Custom</option>
                </select>
              </div>

              {/* Temperature & Tint Controls - Only show if custom is selected */}
              {whiteBalance === 'custom' && (
                <>
                  {/* Temperature Control */}
                  <div>
                    <div className="flex items-center justify-between text-[11px] mb-1">
                      <div className="flex items-center gap-2">
                        <span>Temperature</span>
                        <Tooltip
                          title="Color Temperature"
                          content="Adjust the warmth or coolness of your image. Move right for warmer (yellow) tones, left for cooler (blue) tones."
                        />
                      </div>
                      <span className="text-[var(--text-secondary)]">{settings.temperature || 0}</span>
                    </div>
                    <div className="relative">
                      <div className="h-2 rounded-sm overflow-hidden">
                        <div
                          className="w-full h-full"
                          style={{
                            background: 'linear-gradient(to right, #5B8CFF, #FFFFFF, #FFB800)'
                          }}
                        />
                      </div>
                      <input
                        type="range"
                        min="-100"
                        max="100"
                        value={settings.temperature || 0}
                        onChange={(e) => onSettingChange('temperature', parseInt(e.target.value))}
                        className="absolute top-0 w-full h-2 opacity-0 cursor-pointer"
                      />
                    </div>
                  </div>

                  {/* Tint Control */}
                  <div>
                    <div className="flex justify-between text-[11px] mb-1">
                      <span>Tint</span>
                      <span className="text-[var(--text-secondary)]">{settings.tint || 0}</span>
                    </div>
                    <div className="relative">
                      <div className="h-2 rounded-sm overflow-hidden">
                        <div
                          className="w-full h-full"
                          style={{
                            background: 'linear-gradient(to right, #FF00FF, #FFFFFF, #00FF00)'
                          }}
                        />
                      </div>
                      <input
                        type="range"
                        min="-100"
                        max="100"
                        value={settings.tint || 0}
                        onChange={(e) => onSettingChange('tint', parseInt(e.target.value))}
                        className="absolute top-0 w-full h-2 opacity-0 cursor-pointer"
                      />
                    </div>
                  </div>
                </>
              )}
            </div>

            {/* Tone Controls */}
            <div className="space-y-4">
              <div className="text-sm font-medium">Tone</div>
              {[
                'Exposure',
                'Contrast',
                'Highlights',
                'Shadows',
                'Whites',
                'Blacks',
                'Clarity',
                'Vibrance',
                'Saturation'
              ].map(setting => (
                <div key={setting}>
                  <div className="flex justify-between text-[11px] mb-1">
                    <span>{setting}</span>
                    <span className="text-[var(--text-secondary)]">
                      {settings[setting.toLowerCase()] || 0}
                    </span>
                  </div>
                  <div className="relative">
                    <div className="absolute inset-0 bg-gradient-to-r from-[var(--accent-color)] to-transparent rounded-full opacity-10" style={{ width: `${((settings[setting.toLowerCase()] || 0) + 100) / 2}%` }}></div>
                    <input
                      type="range"
                      min="-100"
                      max="100"
                      value={settings[setting.toLowerCase()] || 0}
                      onChange={(e) => onSettingChange(setting.toLowerCase(), parseInt(e.target.value))}
                      className="w-full h-[3px] bg-[var(--border-color)] rounded-full appearance-none cursor-pointer relative z-10"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Curves Section */}
      <div className="rounded-lg overflow-hidden bg-black">
        <div className="px-4 py-3 flex items-center justify-between text-white">
          <div className="flex items-center">
            <LineChart className="w-4 h-4 mr-2" />
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">Curves</span>
              <Tooltip
                title="RGB Curves"
                content="Adjust the tonal range of your image with precision. RGB affects overall brightness, while individual channels control color balance."
              />
            </div>
          </div>
        </div>
        <div className="px-4 py-4 bg-[#2f2f2f]">
          {/* Channel Selection */}
          <div className="flex space-x-2 mb-4">
            {[
              { id: 'rgb' as const, label: 'RGB', color: 'bg-white text-black', inactiveColor: 'text-white' },
              { id: 'r' as const, label: 'Red', color: 'bg-red-500 text-white', inactiveColor: 'text-red-500' },
              { id: 'g' as const, label: 'Green', color: 'bg-green-500 text-white', inactiveColor: 'text-green-500' },
              { id: 'b' as const, label: 'Blue', color: 'bg-blue-500 text-white', inactiveColor: 'text-blue-500' }
            ].map(channel => (
              <button
                key={channel.id}
                onClick={() => setSelectedChannel(channel.id)}
                className={`px-3 py-1.5 text-[11px] rounded transition-colors ${
                  selectedChannel === channel.id
                    ? channel.color
                    : `${channel.inactiveColor} hover:bg-[var(--hover-bg)]`
                }`}
              >
                {channel.label}
              </button>
            ))}
          </div>

          {/* Curve Editor */}
          <CurveEditor
            width={250}
            height={250}
            points={curvePoints[selectedChannel]}
            onChange={(points) => handleCurveChange(selectedChannel, points)}
            channel={selectedChannel}
          />

          {/* Curve Controls */}
          <div className="mt-4 space-y-4">
            {['Highlights', 'Lights', 'Darks', 'Shadows'].map(curve => (
              <div key={curve}>
                <div className="flex justify-between text-[11px] mb-1">
                  <span>{curve}</span>
                  <span className="text-[var(--text-secondary)]">
                    {settings[curve.toLowerCase()] || 0}
                  </span>
                </div>
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-[var(--accent-color)] to-transparent rounded-full opacity-10" style={{ width: `${((settings[curve.toLowerCase()] || 0) + 100) / 2}%` }}></div>
                  <input
                    type="range"
                    min="-100"
                    max="100"
                    value={settings[curve.toLowerCase()] || 0}
                    onChange={(e) => onSettingChange(curve.toLowerCase(), parseInt(e.target.value))}
                    className="w-full h-[3px] bg-[var(--border-color)] rounded-full appearance-none cursor-pointer relative z-10"
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Color Calibration */}
      <div className="rounded-lg overflow-hidden bg-black">
        <button
          onClick={() => toggleSection('calibration')}
          className="w-full px-4 py-3 flex items-center justify-between text-white hover:bg-white/5 transition-colors"
        >
          <div className="flex items-center">
            <Droplet className="w-4 h-4 mr-2" />
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">Color Calibration</span>
              <Tooltip
                title="Color Calibration"
                content="Fine-tune the primary colors of your image. Adjust hue and saturation to correct color casts or create specific color effects."
              />
            </div>
          </div>
          <ChevronDown
            className={`w-4 h-4 transition-transform ${
              expandedSection === 'calibration' ? 'rotate-180' : ''
            }`}
          />
        </button>

        {expandedSection === 'calibration' && (
          <div className="px-4 py-4 space-y-6 bg-[#2f2f2f]">
            {/* Red Primary */}
            <div className="space-y-4">
              <div className="text-[11px] font-medium text-red-500">Red Primary</div>
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span>Hue</span>
                  <span className="text-[var(--text-secondary)]">
                    {settings.red_primary_hue || 0}
                  </span>
                </div>
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-red-500 to-transparent rounded-full opacity-10" style={{ width: `${((settings.red_primary_hue || 0) + 100) / 2}%` }}></div>
                  <input
                    type="range"
                    min="-100"
                    max="100"
                    value={settings.red_primary_hue || 0}
                    onChange={(e) => onSettingChange('red_primary_hue', parseInt(e.target.value))}
                    className="w-full h-[3px] bg-[var(--border-color)] rounded-full appearance-none cursor-pointer relative z-10"
                  />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span>Saturation</span>
                  <span className="text-[var(--text-secondary)]">
                    {settings.red_primary_saturation || 0}
                  </span>
                </div>
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-red-500 to-transparent rounded-full opacity-10" style={{ width: `${((settings.red_primary_saturation || 0) + 100) / 2}%` }}></div>
                  <input
                    type="range"
                    min="-100"
                    max="100"
                    value={settings.red_primary_saturation || 0}
                    onChange={(e) => onSettingChange('red_primary_saturation', parseInt(e.target.value))}
                    className="w-full h-[3px] bg-[var(--border-color)] rounded-full appearance-none cursor-pointer relative z-10"
                  />
                </div>
              </div>
            </div>

            {/* Green Primary */}
            <div className="space-y-4">
              <div className="text-[11px] font-medium text-green-500">Green Primary</div>
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span>Hue</span>
                  <span className="text-[var(--text-secondary)]">
                    {settings.green_primary_hue || 0}
                  </span>
                </div>
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-green-500 to-transparent rounded-full opacity-10" style={{ width: `${((settings.green_primary_hue || 0) + 100) / 2}%` }}></div>
                  <input
                    type="range"
                    min="-100"
                    max="100"
                    value={settings.green_primary_hue || 0}
                    onChange={(e) => onSettingChange('green_primary_hue', parseInt(e.target.value))}
                    className="w-full h-[3px] bg-[var(--border-color)] rounded-full appearance-none cursor-pointer relative z-10"
                  />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span>Saturation</span>
                  <span className="text-[var(--text-secondary)]">
                    {settings.green_primary_saturation || 0}
                  </span>
                </div>
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-green-500 to-transparent rounded-full opacity-10" style={{ width: `${((settings.green_primary_saturation || 0) + 100) / 2}%` }}></div>
                  <input
                    type="range"
                    min="-100"
                    max="100"
                    value={settings.green_primary_saturation || 0}
                    onChange={(e) => onSettingChange('green_primary_saturation', parseInt(e.target.value))}
                    className="w-full h-[3px] bg-[var(--border-color)] rounded-full appearance-none cursor-pointer relative z-10"
                  />
                </div>
              </div>
            </div>

            {/* Blue Primary */}
            <div className="space-y-4">
              <div className="text-[11px] font-medium text-blue-500">Blue Primary</div>
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span>Hue</span>
                  <span className="text-[var(--text-secondary)]">
                    {settings.blue_primary_hue || 0}
                  </span>
                </div>
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-transparent rounded-full opacity-10" style={{ width: `${((settings.blue_primary_hue || 0) + 100) / 2}%` }}></div>
                  <input
                    type="range"
                    min="-100"
                    max="100"
                    value={settings.blue_primary_hue || 0}
                    onChange={(e) => onSettingChange('blue_primary_hue', parseInt(e.target.value))}
                    className="w-full h-[3px] bg-[var(--border-color)] rounded-full appearance-none cursor-pointer relative z-10"
                  />
                </div>
              </div>
              <div>
                <div className="flex justify-between text-[11px] mb-1">
                  <span>Saturation</span>
                  <span className="text-[var(--text-secondary)]">
                    {settings.blue_primary_saturation || 0}
                  </span>
                </div>
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-transparent rounded-full opacity-10" style={{ width: `${((settings.blue_primary_saturation || 0) + 100) / 2}%` }}></div>
                  <input
                    type="range"
                    min="-100"
                    max="100"
                    value={settings.blue_primary_saturation || 0}
                    onChange={(e) => onSettingChange('blue_primary_saturation', parseInt(e.target.value))}
                    className="w-full h-[3px] bg-[var(--border-color)] rounded-full appearance-none cursor-pointer relative z-10"
                  />
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Detail Section */}
      <div className="rounded-lg overflow-hidden bg-black">
        <button
          onClick={() => toggleSection('detail')}
          className="w-full px-4 py-3 flex items-center justify-between text-white hover:bg-white/5 transition-colors"
        >
          <div className="flex items-center">
            <Focus className="w-4 h-4 mr-2" />
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">Detail</span>
              <Tooltip
                title="Detail Enhancement"
                content="Control image sharpness and noise reduction. Balance detail preservation with noise suppression for optimal results."
              />
            </div>
          </div>
          <ChevronDown
            className={`w-4 h-4 transition-transform ${
              expandedSection === 'detail' ? 'rotate-180' : ''
            }`}
          />
        </button>

        {expandedSection === 'detail' && (
          <div className="px-4 py-4 space-y-4 bg-[#2f2f2f]">
            {['Sharpen', 'Radius', 'Detail', 'Noise Reduction Detail', 'Noise Reduction Contrast'].map(detail => (
              <div key={detail}>
                <div className="flex justify-between text-[11px] mb-1">
                  <span>{detail}</span>
                  <span className="text-[var(--text-secondary)]">
                    {settings[detail.toLowerCase().replace(/\s+/g, '_')] || 0}
                  </span>
                </div>
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-[var(--accent-color)] to-transparent rounded-full opacity-10" style={{ width: `${settings[detail.toLowerCase().replace(/\s+/g, '_')] || 0}%` }}></div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={settings[detail.toLowerCase().replace(/\s+/g, '_')] || 0}
                    onChange={(e) => onSettingChange(detail.toLowerCase().replace(/\s+/g, '_'), parseInt(e.target.value))}
                    className="w-full h-[3px] bg-[var(--border-color)] rounded-full appearance-none cursor-pointer relative z-10"
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Color Noise Reduction */}
      <div className="rounded-lg overflow-hidden bg-black">
        <button
          onClick={() => toggleSection('noise')}
          className="w-full px-4 py-3 flex items-center justify-between text-white hover:bg-white/5 transition-colors"
        >
          <div className="flex items-center">
            <Palette className="w-4 h-4 mr-2" />
            <span className="text-sm font-medium">Color Noise Reduction</span>
          </div>
          <ChevronDown
            className={`w-4 h-4 transition-transform ${
              expandedSection === 'noise' ? 'rotate-180' : ''
            }`}
          />
        </button>

        {expandedSection === 'noise' && (
          <div className="px-4 py-4 space-y-4 bg-[#2f2f2f]">
            {['Detail', 'Smoothness'].map(setting => (
              <div key={`noise_${setting}`}>
                <div className="flex justify-between text-[11px] mb-1">
                  <span>{setting}</span>
                  <span className="text-[var(--text-secondary)]">
                    {settings[`noise_${setting.toLowerCase()}`] || 0}
                  </span>
                </div>
                <div className="relative">
                  <div className="absolute inset-0 bg-gradient-to-r from-[var(--accent-color)] to-transparent rounded-full opacity-10" style={{ width: `${settings[`noise_${setting.toLowerCase()}`] || 0}%` }}></div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={settings[`noise_${setting.toLowerCase()}`] || 0}
                    onChange={(e) => onSettingChange(`noise_${setting.toLowerCase()}`, parseInt(e.target.value))}
                    className="w-full h-[3px] bg-[var(--border-color)] rounded-full appearance-none cursor-pointer relative z-10"
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ColorAdjustment;

export { ColorAdjustment }