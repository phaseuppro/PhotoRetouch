import React from 'react';
import {
  ReactCompareSlider,
  ReactCompareSliderImage
} from 'react-compare-slider';

interface ImageCompareProps {
  originalImage: string;
  processedImage: string;
  zoom?: number;
}

export const ImageCompare: React.FC<ImageCompareProps> = ({
  originalImage,
  processedImage,
  zoom = 100
}) => {
  return (
    <div className="image-container" style={{ transform: `scale(${zoom / 100})` }}>
      <ReactCompareSlider
        itemOne={<ReactCompareSliderImage src={originalImage} alt="Original" />}
        itemTwo={<ReactCompareSliderImage src={processedImage} alt="Processed" />}
        position={50}
        className="max-h-[80vh]"
        style={{ maxWidth: '80vw' }}
      />
    </div>
  );
};