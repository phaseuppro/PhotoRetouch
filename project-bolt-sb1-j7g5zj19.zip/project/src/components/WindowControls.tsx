import React from 'react';

export const WindowControls: React.FC = () => {
  return (
    <div className="window-controls">
      <button className="window-button close" title="Close" />
      <button className="window-button minimize" title="Minimize" />
      <button className="window-button maximize" title="Maximize" />
    </div>
  );
};