import React, { useState } from 'react';
import { Shirt, Wand2, ChevronDown } from 'lucide-react';
import { Tooltip } from './Tooltip';

interface ClothingAdjustmentProps {
  settings: Record<string, number>;
  onSettingChange: (setting: string, value: number) => void;
  selectedSubject: string;
  onSubjectSelect: (subject: string) => void;
}

export const ClothingAdjustment: React.FC<ClothingAdjustmentProps> = ({
  settings,
  onSettingChange,
  selectedSubject,
  onSubjectSelect,
}) => {
  const [expandedSection, setExpandedSection] = useState<string | null>('wrinkles');
  
  const toggleSection = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  const wrinkleSettings = [
    { 
      id: 'removeFineWrinkles', 
      label: 'Remove Fine Wrinkles',
      tooltip: 'Smoothly remove small wrinkles while preserving natural fabric texture'
    },
    { 
      id: 'removeDeepWrinkles', 
      label: 'Remove Deep Wrinkles',
      tooltip: 'Address prominent wrinkles and creases in clothing'
    },
    { 
      id: 'preserveTexture', 
      label: 'Preserve Fabric Texture',
      tooltip: 'Maintain the natural look and feel of the fabric while reducing wrinkles'
    },
    { 
      id: 'enhanceFolds', 
      label: 'Enhance Natural Folds',
      tooltip: 'Emphasize intentional fabric folds for a more professional look'
    }
  ];

  const colorSettings = [
    { 
      id: 'colorCorrection', 
      label: 'Color Correction',
      tooltip: 'Adjust and balance clothing colors for optimal appearance'
    },
    { 
      id: 'saturationBoost', 
      label: 'Saturation Boost',
      tooltip: 'Enhance color vibrancy without over-processing'
    },
    { 
      id: 'contrastEnhancement', 
      label: 'Contrast Enhancement',
      tooltip: 'Improve definition between light and dark areas'
    }
  ];

  const fitSettings = [
    { 
      id: 'slimming', 
      label: 'Slimming Effect',
      tooltip: 'Subtly adjust clothing fit for a more flattering silhouette'
    },
    { 
      id: 'shoulderAlignment', 
      label: 'Shoulder Alignment',
      tooltip: 'Correct shoulder seam positioning and balance'
    },
    { 
      id: 'hemAlignment', 
      label: 'Hem Alignment',
      tooltip: 'Ensure straight and even hemlines'
    }
  ];

  return (
    <div className="p-2 space-y-2">
      {/* Wrinkle Removal Section */}
      <div className="rounded-lg overflow-hidden bg-black">
        <button
          onClick={() => toggleSection('wrinkles')}
          className="w-full px-4 py-3 flex items-center justify-between text-white hover:bg-white/5 transition-colors"
        >
          <div className="flex items-center">
            <Wand2 className="w-4 h-4 mr-2" />
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">Wrinkle Removal</span>
              <Tooltip
                title="Wrinkle Removal"
                content="Smart wrinkle reduction that preserves natural fabric appearance"
              />
            </div>
          </div>
          <ChevronDown
            className={`w-4 h-4 transition-transform ${
              expandedSection === 'wrinkles' ? 'rotate-180' : ''
            }`}
          />
        </button>

        {expandedSection === 'wrinkles' && (
          <div className="px-4 py-4 space-y-4 bg-[#2f2f2f]">
            {wrinkleSettings.map(setting => (
              <div key={setting.id} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-sm">{setting.label}</span>
                  <Tooltip title={setting.label} content={setting.tooltip} />
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings[setting.id] === 100}
                    onChange={(e) => onSettingChange(setting.id, e.target.checked ? 100 : 0)}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-[var(--border-color)] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[var(--accent-color)]"></div>
                </label>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Color Correction Section */}
      <div className="rounded-lg overflow-hidden bg-black">
        <button
          onClick={() => toggleSection('color')}
          className="w-full px-4 py-3 flex items-center justify-between text-white hover:bg-white/5 transition-colors"
        >
          <div className="flex items-center">
            <Shirt className="w-4 h-4 mr-2" />
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">Color Correction</span>
              <Tooltip
                title="Color Correction"
                content="Enhance and balance clothing colors while maintaining natural appearance"
              />
            </div>
          </div>
          <ChevronDown
            className={`w-4 h-4 transition-transform ${
              expandedSection === 'color' ? 'rotate-180' : ''
            }`}
          />
        </button>

        {expandedSection === 'color' && (
          <div className="px-4 py-4 space-y-4 bg-[#2f2f2f]">
            {colorSettings.map(setting => (
              <div key={setting.id} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-sm">{setting.label}</span>
                  <Tooltip title={setting.label} content={setting.tooltip} />
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings[setting.id] === 100}
                    onChange={(e) => onSettingChange(setting.id, e.target.checked ? 100 : 0)}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-[var(--border-color)] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[var(--accent-color)]"></div>
                </label>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Fit Adjustment Section */}
      <div className="rounded-lg overflow-hidden bg-black">
        <button
          onClick={() => toggleSection('fit')}
          className="w-full px-4 py-3 flex items-center justify-between text-white hover:bg-white/5 transition-colors"
        >
          <div className="flex items-center">
            <Shirt className="w-4 h-4 mr-2" />
            <div className="flex items-center gap-2">
              <span className="text-sm font-medium">Fit Adjustment</span>
              <Tooltip
                title="Fit Adjustment"
                content="Fine-tune clothing fit and alignment for a polished look"
              />
            </div>
          </div>
          <ChevronDown
            className={`w-4 h-4 transition-transform ${
              expandedSection === 'fit' ? 'rotate-180' : ''
            }`}
          />
        </button>

        {expandedSection === 'fit' && (
          <div className="px-4 py-4 space-y-4 bg-[#2f2f2f]">
            {fitSettings.map(setting => (
              <div key={setting.id} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-sm">{setting.label}</span>
                  <Tooltip title={setting.label} content={setting.tooltip} />
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={settings[setting.id] === 100}
                    onChange={(e) => onSettingChange(setting.id, e.target.checked ? 100 : 0)}
                    className="sr-only peer"
                  />
                  <div className="w-9 h-5 bg-[var(--border-color)] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[var(--accent-color)]"></div>
                </label>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};