import React from 'react';

export type SubjectType = 'male' | 'female' | 'child' | 'senior' | 'all';

interface SubjectSelectorProps {
  selectedSubject: SubjectType;
  onSubjectSelect: (subject: SubjectType) => void;
}

export const SubjectSelector: React.FC<SubjectSelectorProps> = ({
  selectedSubject,
  onSubjectSelect,
}) => {
  return (
    <div className="subject-selector">
      <h2 className="section-title">Portrait Retouching</h2>
      <div className="subject-buttons">
        <button
          onClick={() => onSubjectSelect('male')}
          className={`subject-button ${selectedSubject === 'male' ? 'active' : ''}`}
        >
          Male
        </button>
        <button
          onClick={() => onSubjectSelect('female')}
          className={`subject-button ${selectedSubject === 'female' ? 'active' : ''}`}
        >
          Female
        </button>
        <button
          onClick={() => onSubjectSelect('child')}
          className={`subject-button ${selectedSubject === 'child' ? 'active' : ''}`}
        >
          Child
        </button>
        <button
          onClick={() => onSubjectSelect('senior')}
          className={`subject-button ${selectedSubject === 'senior' ? 'active' : ''}`}
        >
          Senior
        </button>
        <button
          onClick={() => onSubjectSelect('all')}
          className={`subject-button ${selectedSubject === 'all' ? 'active' : ''}`}
        >
          All
        </button>
      </div>
    </div>
  );
};