import React from 'react';
import {
  Palette,
  UserCircle2,
  Image as ImageIcon,
  Shirt,
  Crop,
  Settings,
  History,
  Download,
  Share2
} from 'lucide-react';

interface ToolBarProps {
  selectedTool: string;
  onToolSelect: (tool: string) => void;
}

export const ToolBar: React.FC<ToolBarProps> = ({ selectedTool, onToolSelect }) => {
  const tools = [
    { 
      id: 'color', 
      icon: Palette, 
      label: 'Color Adjustments',
      description: 'Adjust colors, exposure, and tones'
    },
    { 
      id: 'portrait', 
      icon: UserCircle2, 
      label: 'Portrait Retouching',
      description: 'Enhance facial features and skin'
    },
    { 
      id: 'background', 
      icon: ImageIcon, 
      label: 'Background Adjustments',
      description: 'Modify or replace backgrounds'
    },
    { 
      id: 'clothing', 
      icon: Shirt, 
      label: 'Clothing & Accessories',
      description: 'Enhance and adjust clothing'
    },
    { 
      id: 'crop', 
      icon: Crop, 
      label: 'Crop & Rotate',
      description: 'Adjust image composition'
    }
  ];

  const utilityTools = [
    { id: 'settings', icon: Settings, label: 'Settings' },
    { id: 'history', icon: History, label: 'History' },
    { id: 'export', icon: Download, label: 'Export' },
    { id: 'share', icon: Share2, label: 'Share' }
  ];

  return (
    <div className="tool-bar">
      {/* Main Tools */}
      <div className="flex-1 flex flex-col items-center gap-1 py-2">
        {tools.map((tool) => (
          <button
            key={tool.id}
            onClick={() => onToolSelect(tool.id)}
            className={`tool-button group relative ${selectedTool === tool.id ? 'active' : ''}`}
            title={`${tool.label}\n${tool.description}`}
          >
            <tool.icon className="w-5 h-5" />
            
            {/* Tooltip */}
            <div className="absolute left-full ml-2 px-2 py-1 bg-black/90 text-white text-xs rounded pointer-events-none opacity-0 group-hover:opacity-100 whitespace-nowrap z-10">
              <div className="font-medium">{tool.label}</div>
              <div className="text-[10px] text-gray-300">{tool.description}</div>
            </div>
          </button>
        ))}
      </div>

      {/* Utility Tools */}
      <div className="flex flex-col items-center gap-1 py-2 border-t border-[var(--border-color)]">
        {utilityTools.map((tool) => (
          <button
            key={tool.id}
            onClick={() => onToolSelect(tool.id)}
            className={`tool-button group relative ${selectedTool === tool.id ? 'active' : ''}`}
            title={tool.label}
          >
            <tool.icon className="w-5 h-5" />
            
            {/* Tooltip */}
            <div className="absolute left-full ml-2 px-2 py-1 bg-black/90 text-white text-xs rounded pointer-events-none opacity-0 group-hover:opacity-100 whitespace-nowrap z-10">
              {tool.label}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};