import React, { useState } from 'react';
import { Info, ChevronDown } from 'lucide-react';
import { Tooltip } from './Tooltip';

interface RetouchTool {
  id: string;
  label: string;
  hasInfo?: boolean;
  category: string;
  isToggle?: boolean;
}

export const RetouchTools: React.FC = () => {
  const [settings, setSettings] = useState<Record<string, number>>({});
  const [toggles, setToggles] = useState<Record<string, boolean>>({});
  const [expandedSection, setExpandedSection] = useState<string | null>('blemishes');

  const tools: RetouchTool[] = [
    // Blemishes Category
    { id: 'freckles', label: 'Freckles', category: 'Blemishes' },
    { id: 'acne', label: 'Acne', category: 'Blemishes' },
    { id: 'faceMoleRemoval', label: 'Face Mole Removal', category: 'Blemishes', isToggle: true },
    { id: 'bodyBlemishes', label: 'Body Blemishes', category: 'Blemishes' },
    { id: 'reduceFaceShine', label: 'Reduce Face Shine', category: 'Blemishes' },
    
    // Wrinkles Category
    { id: 'foreheadWrinkles', label: 'Forehead Wrinkles', category: 'Wrinkles' },
    { id: 'eyeWrinkles', label: 'Eye Wrinkles', category: 'Wrinkles' },
    { id: 'darkCircles', label: 'Dark Circles', category: 'Wrinkles', hasInfo: true },
    { id: 'smileLines', label: 'Smile Lines', category: 'Wrinkles', hasInfo: true },
    { id: 'lipWrinkles', label: 'Lip Wrinkles', category: 'Wrinkles' },
    { id: 'neckWrinkles', label: 'Neck Wrinkles', category: 'Wrinkles' },
    
    // Features Category
    { id: 'eyeBags', label: 'Eye Bags', category: 'Features' },
    { id: 'lowerEyelids', label: 'Lower Eyelids', category: 'Features' },
    { id: 'doubleChin', label: 'Double Chin', category: 'Features', hasInfo: true },
    { id: 'glassesGlare', label: 'Remove Glasses Glare', category: 'Features' }
  ];

  const categories = Array.from(new Set(tools.map(tool => tool.category)));

  const handleSettingChange = (toolId: string, value: number) => {
    setSettings(prev => ({ ...prev, [toolId]: value }));
  };

  const handleToggle = (toolId: string) => {
    setToggles(prev => ({ ...prev, [toolId]: !prev[toolId] }));
  };

  const toggleSection = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  return (
    <div className="p-2 space-y-2">
      {categories.map((category) => (
        <div key={category} className="rounded-lg overflow-hidden bg-black">
          <button
            onClick={() => toggleSection(category.toLowerCase())}
            className="w-full px-4 py-3 flex items-center justify-between text-white hover:bg-white/5 transition-colors"
          >
            <span className="text-sm font-medium">{category}</span>
            <ChevronDown
              className={`w-4 h-4 transition-transform ${
                expandedSection === category.toLowerCase() ? 'rotate-180' : ''
              }`}
            />
          </button>

          {expandedSection === category.toLowerCase() && (
            <div className="px-4 py-4 space-y-4 bg-[#2f2f2f]">
              {tools
                .filter(tool => tool.category === category)
                .map(tool => (
                  <div key={tool.id} className="tool-item">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center flex-1 min-w-0 mr-3">
                        <span className="text-[11px] truncate">{tool.label}</span>
                        {tool.hasInfo && tool.id === 'darkCircles' && (
                          <Tooltip
                            title="Dark Circles Reduction"
                            content="Intelligently brighten under-eye areas while maintaining natural skin texture and avoiding an over-processed look."
                          />
                        )}
                        {tool.hasInfo && tool.id === 'smileLines' && (
                          <Tooltip
                            title="Smile Lines"
                            content="Soften nasolabial folds while preserving natural facial expressions and character."
                          />
                        )}
                        {tool.hasInfo && tool.id === 'doubleChin' && (
                          <Tooltip
                            title="Double Chin Reduction"
                            content="Subtly refine chin and neck area while maintaining natural face structure and avoiding distortion."
                          />
                        )}
                      </div>
                      {tool.isToggle ? (
                        <div className="flex-shrink-0">
                          <input
                            type="checkbox"
                            checked={toggles[tool.id] || false}
                            onChange={() => handleToggle(tool.id)}
                            className="sr-only peer"
                            id={`toggle-${tool.id}`}
                          />
                          <label
                            htmlFor={`toggle-${tool.id}`}
                            className="w-9 h-5 bg-[var(--border-color)] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-[var(--accent-color)] cursor-pointer relative block"
                          ></label>
                        </div>
                      ) : (
                        <span className="text-[10px] text-[var(--text-secondary)] flex-shrink-0 ml-2 w-8 text-right">
                          {settings[tool.id] || 0}
                        </span>
                      )}
                    </div>
                    {!tool.isToggle && (
                      <div className="relative">
                        <div className="absolute inset-0 bg-gradient-to-r from-[var(--accent-color)] to-transparent rounded-full opacity-10" style={{ width: `${settings[tool.id] || 0}%` }}></div>
                        <input
                          type="range"
                          min="0"
                          max="100"
                          value={settings[tool.id] || 0}
                          onChange={(e) => handleSettingChange(tool.id, parseInt(e.target.value))}
                          className="w-full h-[3px] bg-[var(--border-color)] rounded-full appearance-none cursor-pointer relative z-10"
                        />
                      </div>
                    )}
                  </div>
                ))}
            </div>
          )}
        </div>
      ))}
    </div>
  );
};