import React, { useState } from 'react';
import { Upload } from 'lucide-react';
import { ImageUploader } from './ImageUploader';

interface ImageViewProps {
  image: string | null;
  onUpload?: (file: File) => void;
}

export const ImageView: React.FC<ImageViewProps> = ({ image, onUpload }) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [error, setError] = useState(false);
  const [retry, setRetry] = useState(true);

  const handleImageError = () => {
    if (retry) {
      setRetry(false);
      setTimeout(() => {
        setRetry(true);
        setError(false);
        setIsLoaded(false);
      }, 500);
    } else {
      setError(true);
      setIsLoaded(false);
    }
  };

  if (!image) {
    return (
      <div className="w-full h-full flex items-center justify-center">
        {onUpload ? (
          <ImageUploader onUpload={onUpload}>
            <button className="px-6 py-3 bg-[var(--accent-color)] text-black rounded-lg hover:opacity-90 transition-opacity flex items-center space-x-2">
              <Upload className="w-5 h-5" />
              <span>Upload Photo</span>
            </button>
          </ImageUploader>
        ) : (
          <div className="text-[var(--text-secondary)]">
            No image selected
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="w-full h-full flex items-center justify-center">
      {error ? (
        <div className="text-red-500">Failed to load image</div>
      ) : (
        <img
          src={image}
          alt="Photo"
          className={`max-w-[80vw] max-h-[80vh] transition-opacity duration-200 ${
            isLoaded ? 'opacity-100' : 'opacity-0'
          }`}
          style={{ objectFit: 'contain' }}
          onLoad={() => {
            setIsLoaded(true);
            setError(false);
          }}
          onError={handleImageError}
        />
      )}
    </div>
  );
};