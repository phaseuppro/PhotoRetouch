import React, { useEffect, useRef, useState } from 'react';
import * as d3 from 'd3';
import { Info } from 'lucide-react';

interface Point {
  x: number;
  y: number;
}

interface CurveEditorProps {
  width?: number;
  height?: number;
  points: Point[];
  onChange: (points: Point[]) => void;
  channel?: 'rgb' | 'r' | 'g' | 'b';
}

export const CurveEditor: React.FC<CurveEditorProps> = ({
  width = 250,
  height = 250,
  points,
  onChange,
  channel = 'rgb'
}) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const dragStartRef = useRef<{ x: number; y: number } | null>(null);

  // Get background color based on channel
  const getBackgroundColor = () => {
    switch (channel) {
      case 'r': return 'rgba(255, 0, 0, 0.1)';
      case 'g': return 'rgba(0, 255, 0, 0.1)';
      case 'b': return 'rgba(0, 0, 255, 0.1)';
      default: return '#1a1a1a';
    }
  };

  // Get gradient colors based on channel
  const getGradientColors = () => {
    switch (channel) {
      case 'r': return ['rgba(255, 0, 0, 0.2)', 'rgba(255, 0, 0, 0.05)'];
      case 'g': return ['rgba(0, 255, 0, 0.2)', 'rgba(0, 255, 0, 0.05)'];
      case 'b': return ['rgba(0, 0, 255, 0.2)', 'rgba(0, 0, 255, 0.05)'];
      default: return ['rgba(255, 255, 255, 0.1)', 'rgba(255, 255, 255, 0.02)'];
    }
  };

  useEffect(() => {
    if (!svgRef.current) return;

    const svg = d3.select(svgRef.current);
    svg.selectAll('*').remove();

    const margin = { top: 10, right: 10, bottom: 30, left: 10 }; // Increased bottom margin
    const innerWidth = width - margin.left - margin.right;
    const innerHeight = height - margin.top - margin.bottom;

    const xScale = d3.scaleLinear()
      .domain([0, 1])
      .range([0, innerWidth])
      .clamp(true);

    const yScale = d3.scaleLinear()
      .domain([0, 1])
      .range([innerHeight, 0])
      .clamp(true);

    const g = svg.append('g')
      .attr('transform', `translate(${margin.left},${margin.top})`);

    // Define gradient
    const gradientId = `curve-gradient-${channel}`;
    const gradient = svg.append('defs')
      .append('linearGradient')
      .attr('id', gradientId)
      .attr('x1', '0%')
      .attr('y1', '0%')
      .attr('x2', '0%')
      .attr('y2', '100%');

    const [gradientStart, gradientEnd] = getGradientColors();
    gradient.append('stop')
      .attr('offset', '0%')
      .attr('stop-color', gradientStart);

    gradient.append('stop')
      .attr('offset', '100%')
      .attr('stop-color', gradientEnd);

    // Background with gradient
    g.append('rect')
      .attr('width', innerWidth)
      .attr('height', innerHeight)
      .attr('fill', getBackgroundColor())
      .attr('rx', 4)
      .style('cursor', 'crosshair');

    g.append('rect')
      .attr('width', innerWidth)
      .attr('height', innerHeight)
      .attr('fill', `url(#${gradientId})`)
      .attr('rx', 4)
      .style('cursor', 'crosshair')
      .on('click', (event) => {
        if (isDragging) return;
        
        const [x, y] = d3.pointer(event);
        const newPoint = {
          x: Math.round(xScale.invert(x) * 100) / 100,
          y: Math.round(yScale.invert(y) * 100) / 100
        };
        
        const newPoints = [...points, newPoint].sort((a, b) => a.x - b.x);
        onChange(newPoints);
      });

    // Grid
    const gridValues = d3.range(0, 1.1, 0.1);
    const grid = g.append('g')
      .attr('class', 'grid')
      .style('stroke', 'rgba(255,255,255,0.1)')
      .style('stroke-width', 0.5);

    // Vertical grid lines
    grid.selectAll('line.vertical')
      .data(gridValues)
      .join('line')
      .attr('class', 'vertical')
      .attr('x1', d => xScale(d))
      .attr('x2', d => xScale(d))
      .attr('y1', 0)
      .attr('y2', innerHeight);

    // Horizontal grid lines
    grid.selectAll('line.horizontal')
      .data(gridValues)
      .join('line')
      .attr('class', 'horizontal')
      .attr('x1', 0)
      .attr('x2', innerWidth)
      .attr('y1', d => yScale(d))
      .attr('y2', d => yScale(d));

    // Diagonal line
    g.append('line')
      .attr('x1', xScale(0))
      .attr('y1', yScale(0))
      .attr('x2', xScale(1))
      .attr('y2', yScale(1))
      .attr('stroke', 'rgba(255,255,255,0.2)')
      .attr('stroke-width', 1)
      .attr('stroke-dasharray', '4,4');

    // Curve line
    const line = d3.line<Point>()
      .x(d => xScale(d.x))
      .y(d => yScale(d.y))
      .curve(d3.curveMonotoneX);

    g.append('path')
      .datum(points)
      .attr('fill', 'none')
      .attr('stroke', channel === 'rgb' ? '#fff' : 
             channel === 'r' ? '#ff4444' :
             channel === 'g' ? '#44ff44' : '#4444ff')
      .attr('stroke-width', 2)
      .attr('d', line);

    // Points
    const pointsGroup = g.append('g').attr('class', 'points');

    const drag = d3.drag<SVGGElement, Point>()
      .on('start', function(event, d) {
        d3.select(this).raise();
        setIsDragging(true);
        dragStartRef.current = { x: d.x, y: d.y };
      })
      .on('drag', function(event, d) {
        if (!dragStartRef.current) return;

        // Calculate the movement with reduced sensitivity
        const sensitivity = 0.5; // Adjust this value to control movement speed
        const dx = (event.x - xScale(dragStartRef.current.x)) * sensitivity;
        const dy = (event.y - yScale(dragStartRef.current.y)) * sensitivity;

        const newX = Math.max(0, Math.min(1, dragStartRef.current.x + xScale.invert(dx)));
        const newY = Math.max(0, Math.min(1, dragStartRef.current.y + yScale.invert(dy)));
        
        d3.select(this).attr('transform', `translate(${xScale(newX)},${yScale(newY)})`);
        
        const index = points.indexOf(d);
        const newPoints = [...points];
        newPoints[index] = { x: newX, y: newY };
        newPoints.sort((a, b) => a.x - b.x);
        onChange(newPoints);
      })
      .on('end', () => {
        setIsDragging(false);
        dragStartRef.current = null;
      });

    const point = pointsGroup.selectAll('g')
      .data(points)
      .join('g')
      .attr('transform', d => `translate(${xScale(d.x)},${yScale(d.y)})`)
      .style('cursor', 'move')
      .call(drag as any);

    // Larger hit area
    point.append('circle')
      .attr('r', 20)
      .attr('fill', 'transparent');

    // Visible handle
    point.append('circle')
      .attr('r', 8)
      .attr('fill', 'transparent')
      .attr('stroke', channel === 'rgb' ? 'rgba(255,255,255,0.5)' :
             channel === 'r' ? 'rgba(255,0,0,0.5)' :
             channel === 'g' ? 'rgba(0,255,0,0.5)' :
             'rgba(0,0,255,0.5)')
      .attr('stroke-width', 2);

    // Center point
    point.append('circle')
      .attr('r', 4)
      .attr('fill', channel === 'rgb' ? '#fff' : 
             channel === 'r' ? '#ff4444' :
             channel === 'g' ? '#44ff44' : '#4444ff');

    // Double-click to remove points
    point.on('dblclick', (event, d) => {
      event.preventDefault();
      if (points.length > 2) {
        const newPoints = points.filter(p => p !== d);
        onChange(newPoints);
      }
    });

    // Add value labels at the bottom
    const labels = [
      { text: 'Shadows', x: 0.15 },
      { text: 'Midtones', x: 0.5 },
      { text: 'Highlights', x: 0.85 }
    ];

    const labelGroup = g.append('g')
      .attr('transform', `translate(0, ${innerHeight + 15})`);

    labels.forEach(label => {
      labelGroup.append('text')
        .attr('x', xScale(label.x))
        .attr('y', 0)
        .attr('text-anchor', 'middle')
        .attr('fill', 'var(--text-secondary)')
        .style('font-size', '11px')
        .text(label.text);

      // Add tick marks
      labelGroup.append('line')
        .attr('x1', xScale(label.x))
        .attr('x2', xScale(label.x))
        .attr('y1', -5)
        .attr('y2', -2)
        .attr('stroke', 'var(--text-secondary)')
        .attr('stroke-width', 1);
    });

  }, [points, width, height, channel, onChange, isDragging]);

  return (
    <div className="space-y-2">
      <svg
        ref={svgRef}
        width={width}
        height={height}
        className="rounded-lg"
        style={{
          background: getBackgroundColor()
        }}
      />
      <div className="flex items-center gap-1.5 text-[10px] text-[var(--text-secondary)]">
        <Info className="w-3.5 h-3.5" />
        <span>Click to add • Drag to move • Double-click to remove</span>
      </div>
    </div>
  );
};