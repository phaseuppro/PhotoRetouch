import React, { useState, useEffect, useRef } from 'react';
import { WindowControls } from './WindowControls';
import { 
  Undo2, Redo2, Copy, Clipboard, Trash2, 
  MousePointer, ChevronLeft, ChevronRight, HelpCircle,
  Download, Share2, ArrowLeft
} from 'lucide-react';

interface TopMenuBarProps {
  onUndo?: () => void;
  onRedo?: () => void;
  onCopy?: () => void;
  onPaste?: () => void;
  onDelete?: () => void;
  onDuplicate?: () => void;
  onDownload?: () => void;
  onShare?: () => void;
  onBack?: () => void;
  canUndo?: boolean;
  canRedo?: boolean;
  hasPreviousPhoto?: boolean;
  hasNextPhoto?: boolean;
}

export const TopMenuBar: React.FC<TopMenuBarProps> = ({
  onUndo,
  onRedo,
  onCopy,
  onPaste,
  onDelete,
  onDuplicate,
  onDownload,
  onShare,
  onBack,
  canUndo,
  canRedo,
  hasPreviousPhoto,
  hasNextPhoto,
}) => {
  const [activeMenu, setActiveMenu] = useState<string | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setActiveMenu(null);
      }
    }

    if (activeMenu) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [activeMenu]);

  const handleMenuClick = (menu: string) => {
    setActiveMenu(activeMenu === menu ? null : menu);
  };

  const handleMenuItemClick = (action: () => void) => {
    action();
    setActiveMenu(null);
  };

  const handleMouseLeave = () => {
    setActiveMenu(null);
  };

  const menus = {
    file: [
      {
        label: 'Back to Projects',
        icon: ArrowLeft,
        action: onBack,
        shortcut: '⌘B',
        disabled: !onBack
      },
      {
        label: 'Download',
        icon: Download,
        action: onDownload,
        shortcut: '⌘D',
        disabled: !onDownload
      },
      {
        label: 'Share',
        icon: Share2,
        action: onShare,
        shortcut: '⌘S',
        disabled: !onShare
      }
    ],
    edit: [
      {
        label: 'Undo',
        icon: Undo2,
        action: onUndo,
        shortcut: '⌘Z',
        disabled: !canUndo || !onUndo
      },
      {
        label: 'Redo',
        icon: Redo2,
        action: onRedo,
        shortcut: '⌘⇧Z',
        disabled: !canRedo || !onRedo
      },
      { type: 'separator' },
      {
        label: 'Copy',
        icon: Copy,
        action: onCopy,
        shortcut: '⌘C',
        disabled: !onCopy
      },
      {
        label: 'Paste',
        icon: Clipboard,
        action: onPaste,
        shortcut: '⌘V',
        disabled: !onPaste
      },
      {
        label: 'Duplicate',
        icon: Copy,
        action: onDuplicate,
        shortcut: '⌘D',
        disabled: !onDuplicate
      },
      { type: 'separator' },
      {
        label: 'Delete',
        icon: Trash2,
        action: onDelete,
        shortcut: '⌫',
        danger: true,
        disabled: !onDelete
      }
    ],
    help: [
      {
        label: 'Documentation',
        icon: HelpCircle,
        action: () => window.open('https://docs.example.com', '_blank')
      },
      {
        label: 'Keyboard Shortcuts',
        icon: MousePointer,
        action: () => window.open('https://docs.example.com/shortcuts', '_blank')
      },
      {
        label: 'Support',
        icon: HelpCircle,
        action: () => window.open('https://example.com/support', '_blank')
      }
    ]
  };

  return (
    <div className="h-8 bg-[var(--panel-bg)] border-b border-[var(--border-color)] flex items-center px-3">
      <div className="app-title text-sm font-medium mr-4">PhotoFix</div>
      <div ref={menuRef} className="flex space-x-1" onMouseLeave={handleMouseLeave}>
        {Object.entries(menus).map(([name, items]) => (
          <div key={name} className="relative">
            <button
              onClick={() => handleMenuClick(name)}
              className={`px-3 py-1 text-[11px] rounded hover:bg-[var(--hover-bg)] ${
                activeMenu === name ? 'bg-[var(--hover-bg)]' : ''
              }`}
            >
              {name.charAt(0).toUpperCase() + name.slice(1)}
            </button>

            {activeMenu === name && (
              <div 
                className="absolute top-full left-0 mt-1 bg-[var(--panel-bg)] border border-[var(--border-color)] rounded-lg shadow-lg py-1 min-w-[220px] z-50"
              >
                {items.map((item, index) => (
                  item.type === 'separator' ? (
                    <div key={index} className="border-t border-[var(--border-color)] my-1" />
                  ) : (
                    <button
                      key={index}
                      onClick={() => item.action && handleMenuItemClick(item.action)}
                      disabled={item.disabled}
                      className={`w-full px-3 py-1.5 text-sm flex items-center hover:bg-[var(--hover-bg)] disabled:opacity-50 ${
                        item.danger ? 'text-red-500 hover:text-red-400' : ''
                      }`}
                    >
                      <item.icon className="w-4 h-4 mr-2" />
                      {item.label}
                      {item.shortcut && (
                        <span className="ml-auto text-xs text-[var(--text-secondary)]">
                          {item.shortcut}
                        </span>
                      )}
                    </button>
                  )
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
      <div className="flex-1" />
      <WindowControls />
    </div>
  );
};