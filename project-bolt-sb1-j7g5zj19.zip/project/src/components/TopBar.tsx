import React from 'react';
import { WindowControls } from './WindowControls';

export const TopBar: React.FC = () => {
  return (
    <div className="top-bar">
      <div className="menu-bar">
        <button className="menu-item">Edit</button>
        <button className="menu-item">Help</button>
      </div>
      <WindowControls />
    </div>
  );
};